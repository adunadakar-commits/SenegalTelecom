import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import Navbar from '../components/Navbar';
import { Satellite, Orbit, Telescope, Star, Rocket, Clock, Wifi, Radio, MapPin } from 'lucide-react';

function StarfieldCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    let animId: number;
    const stars: { x: number; y: number; s: number; a: number; v: number }[] = [];
    const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };
    resize();
    window.addEventListener('resize', resize);
    for (let i = 0; i < 300; i++) stars.push({ x: Math.random() * canvas.width, y: Math.random() * canvas.height, s: Math.random() * 2 + 0.3, a: Math.random(), v: Math.random() * 0.005 + 0.002 });
    const animate = () => {
      ctx.fillStyle = '#080E1A';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      stars.forEach(s => { s.a += s.v; if (s.a > 1) s.a = 0; ctx.beginPath(); ctx.arc(s.x, s.y, s.s, 0, Math.PI * 2); ctx.fillStyle = `rgba(255,255,255,${Math.sin(s.a * Math.PI)})`; ctx.fill(); });
      animId = requestAnimationFrame(animate);
    };
    animate();
    return () => { cancelAnimationFrame(animId); window.removeEventListener('resize', resize); };
  }, []);
  return <canvas ref={canvasRef} className="absolute inset-0 z-0" />;
}

const satellites = [
  { name: 'SAT-3/WASC', type: 'Cable Sous-marin', status: 'Actif', latency: '45ms', coverage: 'Afrique-Europe', speed: '340 Gbps' },
  { name: 'ACE', type: 'Cable Sous-marin', status: 'Actif', latency: '52ms', coverage: 'Afrique-Ouest', speed: '5.12 Tbps' },
  { name: 'GLO-1', type: 'Cable Sous-marin', status: 'Actif', latency: '38ms', coverage: 'Global', speed: '2.5 Tbps' },
  { name: '2Africa', type: 'Cable Sous-marin', status: 'Deploiement', latency: '40ms', coverage: 'Afrique-Asie', speed: '180 Tbps' },
];

const events = [
  { title: 'Pluie de meteores des Perseides', date: '12-13 Aout 2025', desc: "Jusqu'a 100 meteores par heure visibles a l'oeil nu depuis l'Afrique de l'Ouest." },
  { title: 'Eclipse solaire annulaire', date: '21 Septembre 2025', desc: 'Visible depuis le Senegal, la Mauritanie et le Mali. Anneau de feu pendant 5 minutes.' },
  { title: 'Opposition de Mars', date: '15 Janvier 2026', desc: 'Mars au plus proche de la Terre. Observation exceptionnelle au telescope.' },
  { title: 'Conjonction Jupiter-Saturne', date: '3 Mars 2026', desc: 'Les deux geants gazeux se rapprochent a moins d\'un degre dans le ciel.' },
];

const coverage = [
  { city: 'Dakar', latency: '12ms', coverage: '5G+ Fibre' },
  { city: 'Thies', latency: '18ms', coverage: '5G Fibre' },
  { city: 'Saint-Louis', latency: '22ms', coverage: '4G+ Fibre' },
  { city: 'Tamba', latency: '35ms', coverage: '4G Fibre' },
  { city: 'Ziguinchor', latency: '28ms', coverage: '4G+ Fibre' },
  { city: 'Kaolack', latency: '25ms', coverage: '5G Fibre' },
  { city: 'Ndiamsyl Peye', latency: '15ms', coverage: '5G+ Fibre Premium' },
];

export default function Space() {
  return (
    <div className="min-h-screen bg-[#080E1A] text-[#E0E6F1] relative overflow-hidden">
      <StarfieldCanvas />
      <div className="relative z-10">
        <Navbar />
        {/* HERO */}
        <section className="relative pt-32 pb-20 overflow-hidden">
          <div className="absolute inset-0">
            <img src="/p5-aurora.jpg" alt="" className="w-full h-full object-cover opacity-30" />
            <div className="absolute inset-0 bg-gradient-to-b from-[#080E1A] via-[#080E1A]/70 to-[#080E1A]" />
          </div>
          <div className="relative z-10 max-w-[1440px] mx-auto px-6 lg:px-12">
            <motion.div className="text-center space-y-6" initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1 }}>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#00E5FF]/30 glass"><Rocket className="w-4 h-4 text-[#00E5FF]" /><span className="text-sm font-medium text-[#00E5FF] tracking-wider">Portail Spatial</span></div>
              <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold font-['Space_Grotesk'] glow-text-cyber">SENEGAL TELECOM <span className="text-gradient-space">SPACE</span></h1>
              <p className="text-xl text-[#8B95A8] max-w-3xl mx-auto leading-relaxed">Connecter l'Afrique depuis l'espace. Notre constellation de satellites et cables sous-marins relient le continent au monde entier avec une latence ultra-faible.</p>
              <div className="flex flex-wrap justify-center gap-8 pt-4">
                {[{ v: '4', l: 'Cables sous-marins' }, { v: '19M+', l: 'Utilisateurs connectes' }, { v: '45ms', l: 'Latence moyenne' }, { v: '8000+', l: 'Km de fibre' }].map(s => (
                  <div key={s.l} className="text-center"><div className="text-3xl lg:text-4xl font-bold text-[#00E5FF] font-['Space_Grotesk']">{s.v}</div><div className="text-sm text-[#8B95A8]">{s.l}</div></div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* SATELLITES / CABLES */}
        <section className="py-16">
          <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
            <motion.div className="flex items-center gap-3 mb-10" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
              <Satellite className="w-7 h-7 text-[#00E5FF]" />
              <h2 className="text-3xl md:text-4xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">Notre <span className="text-[#00E5FF]">Constellation</span></h2>
            </motion.div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
              {satellites.map((s, i) => (
                <motion.div key={s.name} className="p-6 rounded-xl glass hover:border-[#00E5FF]/20 transition-all group" initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}>
                  <div className="flex items-center justify-between mb-4">
                    <Satellite className="w-8 h-8 text-[#00E5FF]" />
                    <span className="px-2 py-1 rounded-full text-xs bg-[#00E5FF]/15 text-[#00E5FF]">{s.status}</span>
                  </div>
                  <h3 className="text-lg font-bold text-[#E0E6F1] font-['Space_Grotesk'] mb-1">{s.name}</h3>
                  <p className="text-xs text-[#8B95A8] mb-4">{s.type}</p>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm"><span className="text-[#8B95A8]">Latence</span><span className="text-[#00E5FF] font-mono">{s.latency}</span></div>
                    <div className="flex justify-between text-sm"><span className="text-[#8B95A8]">Debit</span><span className="text-[#00E5FF] font-mono">{s.speed}</span></div>
                    <div className="flex justify-between text-sm"><span className="text-[#8B95A8]">Couverture</span><span className="text-[#E0E6F1] text-xs">{s.coverage}</span></div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* ISS + SPACE WEATHER */}
        <section className="py-12">
          <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
            <div className="grid lg:grid-cols-3 gap-6">
              <motion.div className="p-8 rounded-2xl glass-strong" style={{ borderColor: 'rgba(0, 229, 255, 0.15)' }} initial={{ opacity: 0, x: -30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
                <div className="flex items-center gap-3 mb-6"><Orbit className="w-6 h-6 text-[#00E5FF]" /><h3 className="text-xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">ISS Tracker</h3></div>
                <div className="space-y-3">
                  {[{ label: 'Position actuelle', value: '14.2°N, 17.4°W' }, { label: 'Altitude', value: '408 km' }, { label: 'Vitesse orbitale', value: '27,600 km/h' }, { label: 'Prochain passage Dakar', value: 'Dans 2h 14min' }].map(d => (
                    <div key={d.label} className="flex items-center justify-between p-3 rounded-lg bg-[#080E1A]"><span className="text-sm text-[#8B95A8]">{d.label}</span><span className="text-sm font-mono text-[#00E5FF]">{d.value}</span></div>
                  ))}
                </div>
              </motion.div>

              <motion.div className="p-8 rounded-2xl glass-strong" style={{ borderColor: 'rgba(0, 229, 255, 0.15)' }} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
                <div className="flex items-center gap-3 mb-6"><Telescope className="w-6 h-6 text-[#00E5FF]" /><h3 className="text-xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">Meteo Spatiale</h3></div>
                <div className="space-y-3">
                  {[{ label: 'Indice UV', value: 'Eleve (8/10)', color: '#FFD700' }, { label: 'Activite solaire', value: 'Moderee', color: '#00E5FF' }, { label: 'Visibilite etoiles', value: 'Excellente', color: '#00FF88' }, { label: 'Phase lunaire', value: 'Pleine Lune', color: '#E0E6F1' }].map(d => (
                    <div key={d.label} className="flex items-center justify-between p-3 rounded-lg bg-[#080E1A]"><span className="text-sm text-[#8B95A8]">{d.label}</span><span className="text-sm font-bold" style={{ color: d.color }}>{d.value}</span></div>
                  ))}
                </div>
              </motion.div>

              <motion.div className="p-8 rounded-2xl glass-strong" style={{ borderColor: 'rgba(0, 229, 255, 0.15)' }} initial={{ opacity: 0, x: 30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
                <div className="flex items-center gap-3 mb-6"><Wifi className="w-6 h-6 text-[#00E5FF]" /><h3 className="text-xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">Couverture Ville</h3></div>
                <div className="space-y-2 max-h-[260px] overflow-y-auto pr-1">
                  {coverage.map(c => (
                    <div key={c.city} className="flex items-center justify-between p-2.5 rounded-lg bg-[#080E1A]">
                      <div className="flex items-center gap-2"><MapPin className="w-3 h-3 text-[#00E5FF]" /><span className="text-sm text-[#E0E6F1]">{c.city}</span></div>
                      <div className="text-right"><div className="text-xs font-mono text-[#00E5FF]">{c.latency}</div><div className="text-[10px] text-[#8B95A8]">{c.coverage}</div></div>
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* SATELLITE IMAGE */}
        <section className="py-12">
          <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
            <motion.div className="rounded-2xl overflow-hidden glass" style={{ borderColor: 'rgba(0, 229, 255, 0.1)' }} initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }}>
              <img src="/p5-satellite.jpg" alt="Satellite" className="w-full h-72 object-cover" />
              <div className="p-6 flex items-center justify-between">
                <div><h4 className="text-lg font-bold text-[#E0E6F1] font-['Space_Grotesk']">Vue d'artiste — Senegal Telecom Satellite</h4><p className="text-sm text-[#8B95A8]">Orbite geostationnaire au-dessus de l'Afrique de l'Ouest</p></div>
                <div className="flex items-center gap-2"><Radio className="w-5 h-5 text-[#00E5FF] animate-pulse" /><span className="text-sm text-[#00E5FF]">Signal ACTIF</span></div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* ASTRONOMICAL EVENTS */}
        <section className="py-12 pb-24">
          <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
            <motion.div className="flex items-center gap-3 mb-10" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
              <Star className="w-7 h-7 text-[#00E5FF]" />
              <h2 className="text-3xl md:text-4xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">Evenements <span className="text-[#00E5FF]">Astronomiques</span></h2>
            </motion.div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
              {events.map((e, i) => (
                <motion.div key={e.title} className="p-6 rounded-xl glass hover:border-[#00E5FF]/15 transition-all" initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}>
                  <Clock className="w-8 h-8 text-[#00E5FF] mb-4" />
                  <h4 className="text-lg font-bold text-[#E0E6F1] font-['Space_Grotesk'] mb-1">{e.title}</h4>
                  <p className="text-sm text-[#00E5FF] mb-3">{e.date}</p>
                  <p className="text-sm text-[#8B95A8] leading-relaxed">{e.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
