import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Navbar from '../components/Navbar';
import { BookOpen, GraduationCap, ArrowLeft, ArrowRight, Volume2, Star, CheckCircle } from 'lucide-react';

// LE LIVRE DE BASE — Alphabet Arabe Curriculum
const alphabetLessons = [
  { letter: 'ا', name: 'Alif', sound: 'A', type: 'Voyelle longue', desc: 'Prononcée comme le a dans "père". C\'est une voyelle longue, elle s\'allonge.', examples: ['أب (ab) — père', 'أم (um) — mère', 'آب (aab) — prêtre'] },
  { letter: 'ب', name: 'Baa', sound: 'B', type: 'Consonne', desc: 'Prononcée comme le b français. Les lèvres se joignent puis s\'ouvrent.', examples: ['باب (baab) — porte', 'بحر (bahr) — mer', 'بيت (bayt) — maison'] },
  { letter: 'ت', name: 'Taa', sound: 'T', type: 'Consonne', desc: 'Prononcée comme le t français. La pointe de la langue touche les gencives supérieures.', examples: ['تاج (taaj) — couronne', 'تمر (tamr) — datte', 'تين (teen) — figue'] },
  { letter: 'ث', name: 'Thaa', sound: 'Th (soufflé)', type: 'Consonne', desc: 'Prononcée comme le th anglais de "think". Souffle entre la langue et les dents.', examples: ['ثوب (thawb) — robe', 'ثوم (thoom) — ail', 'ثلج (thalj) — neige'] },
  { letter: 'ج', name: 'Jiim', sound: 'J (guttural)', type: 'Consonne', desc: 'Prononcée comme un j plus profond, guttural. Le fond de la langue se soulève.', examples: ['جمل (jamal) — chameau', 'جبل (jabal) — montagne', 'جزر (jazar) — carotte'] },
  { letter: 'ح', name: 'Haa', sound: 'H (guttural)', type: 'Consonne', desc: 'Prononcée comme un h expiré fort, guttural. L\'air sort du fond de la gorge.', examples: ['حجر (hajar) — pierre', 'حليب (haleeb) — lait', 'حبيب (habeeb) — bien-aimé'] },
  { letter: 'خ', name: 'Khaa', sound: 'Kh (guttural)', type: 'Consonne', desc: 'Prononcée comme le jota espagnol ou le ch allemand de "Bach". Friction au fond de la gorge.', examples: ['خبز (khubz) — pain', 'خروف (kharoof) — mouton', 'خالد (khaalid) — éternel'] },
  { letter: 'د', name: 'Daal', sound: 'D', type: 'Consonne', desc: 'Prononcée comme le d français. La pointe de la langue touche le palais derrière les dents.', examples: ['دار (daar) — maison', 'دم (dam) — sang', 'دين (deen) — religion'] },
  { letter: 'ذ', name: 'Dhaal', sound: 'Dh (soufflé)', type: 'Consonne', desc: 'Prononcée comme le th anglais de "this". Son voisé, vibration des cordes vocales.', examples: ['ذهب (dhahab) — or', 'ذئب (dhaib) — loup', 'ذرة (dharr) — atome'] },
  { letter: 'ر', name: 'Raa', sound: 'R (roulé)', type: 'Consonne', desc: 'Prononcée comme un r roulé léger. La pointe de la langue vibre contre le palais.', examples: ['رجل (rajul) — homme', 'رحمن (rahmaan) — miséricordieux', 'رب (rabb) — seigneur'] },
  { letter: 'ز', name: 'Zaay', sound: 'Z', type: 'Consonne', desc: 'Prononcée comme le z français. Bourdonnement des cordes vocales.', examples: ['زيت (zayt) — huile', 'زرع (zar3) — semence', 'زهر (zahr) — fleur'] },
  { letter: 'س', name: 'Siin', sound: 'S', type: 'Consonne', desc: 'Prononcée comme le s français. Souffle non voisé entre les dents.', examples: ['سلام (salaam) — paix', 'سماء (samaa) — ciel', 'شمس (shams) — soleil'] },
  { letter: 'ش', name: 'Shiin', sound: 'Sh', type: 'Consonne', desc: 'Prononcée comme le ch français. Lèvres légèrement arrondies.', examples: ['شمس (shams) — soleil', 'شجر (shajar) — arbre', 'شعر (sh3r) — poésie'] },
  { letter: 'ص', name: 'Saad', sound: 'S (épaissie)', type: 'Consonne', desc: 'Prononcée comme un s mais plus épaisse, emphatique. La langue est aplatie.', examples: ['صلاة (salaat) — prière', 'صبر (sabr) — patience', 'صحيح (saheeh) — authentique'] },
  { letter: 'ض', name: 'Daad', sound: 'D (épaissie)', type: 'Consonne', desc: 'Son propre à l\'arabe, d emphatique. Le côté de la langue touche les molaires.', examples: ['ضابط (dhaabit) — officier', 'ضوء (dhaw) — lumière', 'ضيف (dheef) — invité'] },
  { letter: 'ط', name: 'Taa (épaissie)', sound: 'T (épaissie)', type: 'Consonne', desc: 'Prononcée comme un t emphatique, plus fort et profond que le t normal.', examples: ['طالب (taalib) — étudiant', 'طيب (tayyib) — bon', 'طريق (tareeq) — chemin'] },
  { letter: 'ظ', name: 'Dhaa (épaissie)', sound: 'Dh (épaissie)', type: 'Consonne', desc: 'Th voisé emphatique. La langue est aplatie contre le palais.', examples: ['ظالم (dhaalim) — oppresseur', 'ظهر (dhuhr) — midi', 'ظرف (dhurf) — enveloppe'] },
  { letter: 'ع', name: 'Ayn', sound: 'Ayn (guttural)', type: 'Consonne', desc: 'Son guttural profond. Contraction de la gorge comme un hoquet. La lettre la plus arabe.', examples: ['علم (3ilm) — science', 'عربي (3arabee) — arabe', 'عبد (3abd) — serviteur'] },
  { letter: 'غ', name: 'Ghayn', sound: 'Gh (guttural)', type: 'Consonne', desc: 'Prononcée comme un r français très grasseyé ou g guttural. Vibrations profondes.', examples: ['غرب (gharb) — ouest', 'غداء (ghadaa) — déjeuner', 'غفور (ghafoor) — pardonneur'] },
  { letter: 'ف', name: 'Faa', sound: 'F', type: 'Consonne', desc: 'Prononcée comme le f français. La lèvre inférieure touche les dents supérieures.', examples: ['فتح (fath) — ouverture', 'فجر (fajr) — aube', 'فيل (feel) — éléphant'] },
  { letter: 'ق', name: 'Qaaf', sound: 'Q (guttural K)', type: 'Consonne', desc: 'Prononcée comme un k très guttural, loin dans la gorge. Plus profond que le k.', examples: ['قلب (qalb) — coeur', 'قرآن (quran) — Coran', 'قمر (qamar) — lune'] },
  { letter: 'ك', name: 'Kaaf', sound: 'K', type: 'Consonne', desc: 'Prononcée comme le k français. Le dos de la langue touche le voile du palais.', examples: ['كتاب (kitaab) — livre', 'كلب (kalb) — chien', 'كبير (kabeer) — grand'] },
  { letter: 'ل', name: 'Laam', sound: 'L', type: 'Consonne', desc: 'Prononcée comme le l français. La pointe de la langue touche le palais.', examples: ['ليل (layl) — nuit', 'لحم (lahm) — viande', 'لؤلؤ (ulul) — perle'] },
  { letter: 'م', name: 'Miim', sound: 'M', type: 'Consonne', desc: 'Prononcée comme le m français. Les lèvres se ferment, l\'air sort par le nez.', examples: ['ماء (maa) — eau', 'مدينة (madeena) — ville', 'مسلم (muslim) — musulman'] },
  { letter: 'ن', name: 'Nuun', sound: 'N', type: 'Consonne', desc: 'Prononcée comme le n français. La langue touche le palais, l\'air sort par le nez.', examples: ['نور (noor) — lumière', 'نار (naar) — feu', 'نهر (nahr) — fleuve'] },
  { letter: 'ه', name: 'Haa (légère)', sound: 'H (légère)', type: 'Consonne', desc: 'Prononcée comme un h soufflé léger. Différent du haa guttural (ح).', examples: ['هذا (haadhaa) — ceci', 'هو (huwa) — il', 'هبة (hiba) — don'] },
  { letter: 'و', name: 'Waaw', sound: 'W / Ou', type: 'Semi-voyelle', desc: 'Prononcée comme le w français ou la voyelle ou. Lèvres arrondies.', examples: ['ورد (ward) — rose', 'واحد (waahid) — un', 'وجه (wajh) — visage'] },
  { letter: 'ي', name: 'Yaa', sound: 'Y / Ii', type: 'Semi-voyelle', desc: 'Prononcée comme le y français ou la voyelle ii. Lèvres étirées.', examples: ['يد (yad) — main', 'يس (yaseen) — Yaseen', 'يوم (yawm) — jour'] },
];

const vowels = [
  { sign: '◌َ', name: 'Fatha', sound: 'a', desc: 'Trait au-dessus = son "a" comme dans "père"' },
  { sign: '◌ِ', name: 'Kasra', sound: 'i', desc: 'Trait en-dessous = son "i" comme dans "lit"' },
  { sign: '◌ُ', name: 'Damma', sound: 'ou', desc: 'Petit waw au-dessus = son "ou" comme dans "tout"' },
  { sign: '◌ّ', name: 'Shadda', sound: 'Double', desc: 'Petit w au-dessus = consonne doublée' },
  { sign: '◌ْ', name: 'Sukun', sound: 'Muet', desc: 'Petit cercle = pas de voyelle (consonne muette)' },
];

export default function Alphabet() {
  const [activeLesson, setActiveLesson] = useState(0);
  const [activeTab, setActiveTab] = useState('lessons');
  const [completed, setCompleted] = useState<number[]>([]);

  const toggleCompleted = (idx: number) => {
    if (completed.includes(idx)) {
      setCompleted(completed.filter(i => i !== idx));
    } else {
      setCompleted([...completed, idx]);
    }
  };

  const progress = Math.round((completed.length / alphabetLessons.length) * 100);

  return (
    <div className="min-h-screen bg-[#0a1f14] text-[#F5F5DC]">
      <Navbar />
      
      {/* HERO */}
      <section className="relative pt-32 pb-16 overflow-hidden">
        <div className="absolute inset-0">
          <img src="/p2-pattern.jpg" alt="" className="w-full h-full object-cover opacity-20" />
          <div className="absolute inset-0 bg-gradient-to-b from-[#0a1f14] via-[#0a1f14]/80 to-[#0a1f14]" />
        </div>
        <div className="relative z-10 max-w-[1440px] mx-auto px-6 lg:px-12 text-center">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="space-y-4">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#1B8A4C]/30 glass">
              <GraduationCap className="w-4 h-4 text-[#D4AF37]" />
              <span className="text-sm font-medium text-[#D4AF37] tracking-wider">Apprentissage Arabe — LE LIVRE DE BASE</span>
            </div>
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold font-['Space_Grotesk']">
              ALPHABET <span className="text-gradient-islam">ARABE</span>
            </h1>
            <p className="text-xl text-[#8B95A8] max-w-3xl mx-auto">
              Manuel d'initiation à la lecture arabe à travers le Coran. 
              28 leçons pour maîtriser les lettres de l'alphabet arabe.
            </p>
            
            {/* Progress Bar */}
            <div className="max-w-md mx-auto mt-6">
              <div className="flex justify-between text-sm text-[#8B95A8] mb-2">
                <span>Progression</span>
                <span>{progress}% ({completed.length}/28)</span>
              </div>
              <div className="w-full h-3 bg-[#1B8A4C]/20 rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-gradient-to-r from-[#1B8A4C] to-[#D4AF37] rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* TABS */}
      <section className="py-8">
        <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
          <div className="flex flex-wrap gap-3 justify-center mb-8">
            {[{ k: 'lessons', l: 'Leçons', i: BookOpen }, { k: 'vowels', l: 'Voyelles', i: Star }].map(t => (
              <button 
                key={t.k} 
                onClick={() => setActiveTab(t.k)} 
                className={`flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-medium transition-all ${activeTab === t.k ? 'bg-[#1B8A4C] text-white' : 'glass text-[#8B95A8] hover:text-[#E0E6F1]'}`}
              >
                <t.i className="w-4 h-4" />{t.l}
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            {/* LESSONS */}
            {activeTab === 'lessons' && (
              <motion.div key="lessons" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                {/* Lesson Navigation */}
                <div className="flex items-center gap-4 mb-8">
                  <button 
                    onClick={() => setActiveLesson(Math.max(0, activeLesson - 1))}
                    className="p-3 rounded-full glass hover:border-[#D4AF37]/30 transition-all"
                    disabled={activeLesson === 0}
                  >
                    <ArrowLeft className="w-5 h-5 text-[#D4AF37]" />
                  </button>
                  
                  <div className="flex-1 grid grid-cols-7 md:grid-cols-14 gap-2">
                    {alphabetLessons.map((_, idx) => (
                      <button
                        key={idx}
                        onClick={() => setActiveLesson(idx)}
                        className={`w-10 h-10 rounded-lg flex items-center justify-center text-sm font-bold transition-all ${
                          idx === activeLesson 
                            ? 'bg-[#D4AF37] text-[#0a1f14]' 
                            : completed.includes(idx)
                            ? 'bg-[#1B8A4C]/30 text-[#00E5A0] border border-[#1B8A4C]/50'
                            : 'glass text-[#8B95A8] hover:border-[#D4AF37]/20'
                        }`}
                      >
                        {completed.includes(idx) ? <CheckCircle className="w-4 h-4" /> : idx + 1}
                      </button>
                    ))}
                  </div>
                  
                  <button 
                    onClick={() => setActiveLesson(Math.min(alphabetLessons.length - 1, activeLesson + 1))}
                    className="p-3 rounded-full glass hover:border-[#D4AF37]/30 transition-all"
                    disabled={activeLesson === alphabetLessons.length - 1}
                  >
                    <ArrowRight className="w-5 h-5 text-[#D4AF37]" />
                  </button>
                </div>

                {/* Active Lesson Card */}
                <motion.div 
                  key={activeLesson}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4 }}
                  className="max-w-3xl mx-auto"
                >
                  <div className="p-8 md:p-12 rounded-3xl glass-strong border border-[#D4AF37]/20 text-center space-y-8">
                    {/* Letter Display */}
                    <div className="space-y-4">
                      <div className="text-[8rem] md:text-[10rem] leading-none text-[#D4AF37] arabic font-bold animate-float">
                        {alphabetLessons[activeLesson].letter}
                      </div>
                      <div className="text-sm text-[#8B95A8] uppercase tracking-widest">
                        Leçon {activeLesson + 1} sur 28
                      </div>
                    </div>

                    {/* Info */}
                    <div className="space-y-3">
                      <h2 className="text-3xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">
                        {alphabetLessons[activeLesson].name}
                      </h2>
                      <div className="flex items-center justify-center gap-4">
                        <span className="px-4 py-1.5 rounded-full bg-[#1B8A4C]/20 text-[#00E5A0] text-sm font-medium">
                          Son : {alphabetLessons[activeLesson].sound}
                        </span>
                        <span className="px-4 py-1.5 rounded-full bg-[#D4AF37]/20 text-[#D4AF37] text-sm font-medium">
                          {alphabetLessons[activeLesson].type}
                        </span>
                      </div>
                      <p className="text-lg text-[#8B95A8] max-w-lg mx-auto leading-relaxed">
                        {alphabetLessons[activeLesson].desc}
                      </p>
                    </div>

                    {/* Examples */}
                    <div className="grid md:grid-cols-3 gap-4">
                      {alphabetLessons[activeLesson].examples.map((ex, i) => (
                        <div key={i} className="p-4 rounded-xl glass border border-[#1B8A4C]/10">
                          <div className="text-2xl text-[#D4AF37] arabic mb-2">{ex.split(' ')[0]}</div>
                          <div className="text-sm text-[#E0E6F1]">{ex.split(' — ')[1]}</div>
                        </div>
                      ))}
                    </div>

                    {/* Actions */}
                    <div className="flex items-center justify-center gap-4 pt-4">
                      <button 
                        onClick={() => toggleCompleted(activeLesson)}
                        className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all ${
                          completed.includes(activeLesson)
                            ? 'bg-[#1B8A4C] text-white'
                            : 'glass border-[#D4AF37]/30 text-[#D4AF37] hover:bg-[#D4AF37]/10'
                        }`}
                      >
                        {completed.includes(activeLesson) ? (
                          <><CheckCircle className="w-5 h-5" /> Leçon terminée</>
                        ) : (
                          <><CheckCircle className="w-5 h-5" /> Marquer comme terminée</>
                        )}
                      </button>
                      <button className="flex items-center gap-2 px-6 py-3 rounded-xl glass text-[#8B95A8] hover:text-[#E0E6F1] transition-all">
                        <Volume2 className="w-5 h-5" /> Écouter
                      </button>
                    </div>
                  </div>
                </motion.div>
              </motion.div>
            )}

            {/* VOWELS */}
            {activeTab === 'vowels' && (
              <motion.div key="vowels" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="max-w-3xl mx-auto">
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {vowels.map((v, i) => (
                    <motion.div 
                      key={v.name} 
                      className="p-6 rounded-2xl glass-strong border border-[#D4AF37]/10 text-center space-y-3"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.1 }}
                    >
                      <div className="text-5xl text-[#D4AF37] arabic">{v.sign}</div>
                      <h3 className="text-xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">{v.name}</h3>
                      <div className="text-2xl font-bold text-[#00E5A0]">{v.sound}</div>
                      <p className="text-sm text-[#8B95A8]">{v.desc}</p>
                    </motion.div>
                  ))}
                </div>
                
                {/* Rules */}
                <div className="mt-8 p-6 rounded-2xl glass border border-[#1B8A4C]/20">
                  <h3 className="text-xl font-bold text-[#D4AF37] font-['Space_Grotesk'] mb-4">Règles de base</h3>
                  <ul className="space-y-3 text-[#8B95A8]">
                    <li className="flex items-start gap-3"><CheckCircle className="w-5 h-5 text-[#1B8A4C] shrink-0 mt-0.5" /><span>L'alphabet arabe se lit de <strong className="text-[#E0E6F1]">droite à gauche</strong>.</span></li>
                    <li className="flex items-start gap-3"><CheckCircle className="w-5 h-5 text-[#1B8A4C] shrink-0 mt-0.5" /><span>Les lettres prennent des formes différentes selon leur position dans le mot : isolée, initiale, médiane, finale.</span></li>
                    <li className="flex items-start gap-3"><CheckCircle className="w-5 h-5 text-[#1B8A4C] shrink-0 mt-0.5" /><span>Les voyelles (fatha, kasra, damma) s'écrivent au-dessus ou en-dessous des lettres.</span></li>
                    <li className="flex items-start gap-3"><CheckCircle className="w-5 h-5 text-[#1B8A4C] shrink-0 mt-0.5" /><span>La hamza (ء) est une lettre qui représente un coup de glotte, comme le 'entre les deux syllabes de "au-revoir".</span></li>
                    <li className="flex items-start gap-3"><CheckCircle className="w-5 h-5 text-[#1B8A4C] shrink-0 mt-0.5" /><span>6 lettres ne se rattachent jamais à la lettre suivante : ا د ذ ر ز و</span></li>
                  </ul>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>
    </div>
  );
}
