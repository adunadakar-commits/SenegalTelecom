import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import Navbar from '../components/Navbar';
import {
  ArrowRight, Wifi, Cloud, CreditCard, Globe, TrendingUp, Users, Server,
  Award, Clock, Signal, Radio, Zap, Shield, Phone, MapPin, ChevronRight,
  Play, Star, Sparkles, BookOpen
} from 'lucide-react';

/* ===== PARTICLE NETWORK CANVAS ===== */
function ParticleNetwork() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    let animId: number;
    type P = { x: number; y: number; vx: number; vy: number; s: number; a: number; c: string };
    const particles: P[] = [];
    const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };
    resize();
    window.addEventListener('resize', resize);
    for (let i = 0; i < 120; i++) {
      particles.push({
        x: Math.random() * canvas.width, y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.6, vy: (Math.random() - 0.5) * 0.6,
        s: Math.random() * 2.5 + 0.5, a: Math.random() * 0.6 + 0.2,
        c: Math.random() > 0.4 ? '#4D6BFF' : Math.random() > 0.5 ? '#D4AF37' : '#00E5A0'
      });
    }
    const mouse = { x: -1000, y: -1000 };
    const onMove = (e: MouseEvent) => { mouse.x = e.clientX; mouse.y = e.clientY; };
    window.addEventListener('mousemove', onMove);

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach(p => {
        const dmx = mouse.x - p.x, dmy = mouse.y - p.y;
        const dMouse = Math.sqrt(dmx * dmx + dmy * dmy);
        if (dMouse < 200) { p.vx -= dmx * 0.0003; p.vy -= dmy * 0.0003; }
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;
        p.vx *= 0.999; p.vy *= 0.999;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.s, 0, Math.PI * 2);
        ctx.fillStyle = p.c; ctx.globalAlpha = p.a; ctx.fill(); ctx.globalAlpha = 1;
      });
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x, dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 180) {
            ctx.beginPath(); ctx.moveTo(particles[i].x, particles[i].y); ctx.lineTo(particles[j].x, particles[j].y);
            ctx.strokeStyle = `rgba(77,107,255,${0.12 * (1 - dist / 180)})`; ctx.lineWidth = 0.8; ctx.stroke();
          }
        }
      }
      animId = requestAnimationFrame(animate);
    };
    animate();
    return () => { cancelAnimationFrame(animId); window.removeEventListener('resize', resize); window.removeEventListener('mousemove', onMove); };
  }, []);
  return <canvas ref={canvasRef} className="absolute inset-0 z-10 pointer-events-none" />;
}

/* ===== HERO ===== */
function Hero() {
  const ticker = [
    { icon: Zap, text: 'DAKAR DC: 99.9% UPTIME' }, { icon: Server, text: 'FIBRE OPTIQUE: 10 GBPS' },
    { icon: Wifi, text: '5G ROLLOUT: PHASE 3' }, { icon: Radio, text: 'SAT-3 CABLE: ACTIF' },
    { icon: Cloud, text: 'CLOUD NATIONAL: OPERATIONNEL' }, { icon: Wifi, text: '4G COUVERTURE: 98%' },
    { icon: Shield, text: 'ISO 27001 CERTIFIE' }, { icon: Globe, text: '150+ PAYS CONNECTES' },
  ];

  return (
    <section className="relative min-h-screen flex flex-col justify-center overflow-hidden">
      {/* Video Background */}
      <video autoPlay muted loop playsInline className="video-bg z-0">
        <source src="/hero-video.mp4" type="video/mp4" />
      </video>
      <div className="absolute inset-0 z-[1] bg-gradient-to-b from-[#050A14]/70 via-[#050A14]/40 to-[#050A14]" />
      <div className="absolute inset-0 z-[2] bg-gradient-to-r from-[#050A14]/60 via-transparent to-[#050A14]/60" />

      <ParticleNetwork />

      {/* Ticker */}
      <div className="absolute top-24 left-0 w-full z-20 overflow-hidden border-y border-[#4D6BFF]/15 py-2.5 glass">
        <div className="flex animate-marquee whitespace-nowrap">
          {[...ticker, ...ticker, ...ticker].map((item, i) => (
            <div key={i} className="flex items-center gap-2 mx-6">
              <item.icon className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span className="text-xs font-mono text-[#8B95A8] tracking-wider uppercase">{item.text}</span>
              <span className="text-[#4D6BFF]/40 mx-3 text-lg">&#9670;</span>
            </div>
          ))}
        </div>
      </div>

      {/* Hero Content */}
      <div className="relative z-30 max-w-[1440px] mx-auto px-6 lg:px-12 pt-40 pb-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div className="space-y-8" initial={{ opacity: 0, x: -60 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 1, delay: 3.5 }}>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#4D6BFF]/30 glass">
              <div className="w-2 h-2 rounded-full bg-[#00E5A0] animate-pulse-glow" />
              <span className="text-sm font-medium text-[#4D6BFF] tracking-wider">Leader des Telecoms en Afrique de l'Ouest depuis 1985</span>
            </div>

            <h1 className="text-5xl md:text-6xl lg:text-8xl font-bold leading-[1.05] tracking-tight text-[#E0E6F1] font-['Space_Grotesk']">
              L'AFRIQUE,<br />
              <span className="text-gradient-gold glow-text-cyber">CONNECTEE</span><br />
              AU FUTUR
            </h1>

            <p className="text-lg text-[#8B95A8] max-w-lg leading-relaxed">
              SENEGAL TELECOM construit l'infrastructure numerique qui relie le Senegal et l'Afrique de l'Ouest au reste du monde. Fibre optique, 5G, Cloud et services financiers mobiles.
            </p>

            <div className="flex flex-wrap gap-4">
              <Link to="/store" className="group flex items-center gap-3 px-8 py-4 bg-[#4D6BFF] text-white font-semibold tracking-wider uppercase rounded-xl hover:bg-[#3D5BE8] transition-all glow-cyber">
                Decouvrir nos offres <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link to="/space" className="flex items-center gap-3 px-8 py-4 glass text-[#E0E6F1] font-semibold tracking-wider uppercase rounded-xl hover:border-[#4D6BFF]/40 transition-all">
                <Play className="w-4 h-4 text-[#D4AF37]" /> Notre reseau
              </Link>
            </div>

            <div className="flex gap-8 pt-6 border-t border-[#4D6BFF]/15">
              {[{ v: '19M+', l: 'Utilisateurs' }, { v: '5', l: 'Pays' }, { v: '99.9%', l: 'Disponibilite' }, { v: '40+', l: 'Ans' }].map((s) => (
                <div key={s.l}><div className="text-2xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">{s.v}</div><div className="text-xs text-[#8B95A8] mt-0.5">{s.l}</div></div>
              ))}
            </div>
          </motion.div>

          {/* Orbital Visual */}
          <motion.div className="relative hidden lg:block" initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 1.2, delay: 3.8 }}>
            <div className="relative w-full aspect-square max-w-lg mx-auto">
              {[0, 15, 30].map((offset, i) => (
                <div key={i} className="absolute rounded-full border border-[#4D6BFF]/15 animate-spin-slow" style={{ inset: offset, animationDuration: `${20 + i * 8}s`, animationDirection: i % 2 === 1 ? 'reverse' : 'normal' }} />
              ))}
              <div className="absolute inset-20 rounded-full bg-gradient-to-br from-[#4D6BFF]/15 via-[#D4AF37]/10 to-[#00E5A0]/15 animate-pulse-glow flex items-center justify-center">
                <div className="text-center space-y-2">
                  <Signal className="w-14 h-14 text-[#4D6BFF] mx-auto" />
                  <div className="text-xs text-[#8B95A8] tracking-[0.3em] uppercase">Reseau Actif</div>
                  <div className="text-lg font-bold text-[#00E5A0] font-mono">ONLINE</div>
                </div>
              </div>
              {[{ delay: 0, color: '#4D6BFF' }, { delay: 1, color: '#D4AF37' }, { delay: 2, color: '#00E5A0' }].map((node, i) => (
                <div key={i} className="absolute inset-0 animate-spin-slow" style={{ animationDuration: `${10 + i * 6}s`, animationDirection: i % 2 === 1 ? 'reverse' : 'normal' }}>
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 rounded-full glow-cyber" style={{ backgroundColor: node.color, boxShadow: `0 0 20px ${node.color}60` }} />
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 w-full h-40 bg-gradient-to-t from-[#050A14] to-transparent z-20" />
    </section>
  );
}

/* ===== SERVICES ===== */
function Services() {
  const services = [
    { title: 'FIBRE OPTIQUE', subtitle: 'Internet Haut Debit', desc: 'Debit symetrique jusqu\'a 1 Gbps pour les particuliers et les entreprises. Notre reseau fibre couvre tout le territoire national avec plus de 8,000 km de cables.', icon: Wifi, img: '/p1-fiber.jpg', features: ['Jusqu\'a 1 Gbps', 'Install rapide', 'Support 24/7'], color: '#4D6BFF' },
    { title: '5G & MOBILE', subtitle: 'Connectivite Sans Fil', desc: 'Reseau 4G/5G couvrant 98% de la population senegalaise. Appels illimites, data mobile et roaming international dans plus de 150 pays.', icon: Signal, img: '/p1-5g.jpg', features: ['Couverture 98%', 'Roaming 150+ pays', '5G disponible'], color: '#D4AF37' },
    { title: 'CLOUD & DATA', subtitle: 'Solutions Entreprises', desc: 'Hebergement cloud securise, centres de donnees Tier III et solutions de cyber-securite pour les entreprises. Certifie ISO 27001.', icon: Cloud, img: '/p1-cybercafe.jpg', features: ['Tier III DC', 'ISO 27001', 'Backup auto'], color: '#00E5A0' },
  ];

  const extra = [
    { icon: CreditCard, title: 'Aduna Money', desc: 'Transferts et paiements mobiles securises' },
    { icon: Server, title: 'Solutions Pro', desc: 'Offres sur mesure pour entreprises' },
    { icon: Shield, title: 'Cybersecurite', desc: 'Protection avancee des donnees' },
    { icon: Zap, title: 'Support 24/7', desc: 'Assistance technique permanente' },
  ];

  return (
    <section className="relative bg-[#050A14] py-28 overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] rounded-full bg-[#4D6BFF]/5 blur-[120px] pointer-events-none" />
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12 relative z-10">
        <motion.div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-8 mb-20" initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }}>
          <div className="space-y-4">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#4D6BFF]/30 glass"><Wifi className="w-4 h-4 text-[#4D6BFF]" /><span className="text-sm font-medium text-[#4D6BFF] tracking-wider">Nos Solutions</span></div>
            <h2 className="text-4xl md:text-5xl lg:text-7xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">SERVICES<br /><span className="text-gradient-gold">NUMERIQUES</span></h2>
          </div>
          <p className="text-lg text-[#8B95A8] max-w-md lg:text-right">Des solutions completes pour particuliers, entreprises et institutions publiques a travers l'Afrique de l'Ouest.</p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-6">
          {services.map((s, i) => (
            <motion.div key={s.title} className="group relative rounded-2xl overflow-hidden border border-[#4D6BFF]/10 bg-[#0B1426]/60 hover:border-[#4D6BFF]/30 transition-all duration-500" initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6, delay: i * 0.15 }}>
              <div className="relative h-60 overflow-hidden">
                <img src={s.img} alt="" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B1426] via-[#0B1426]/40 to-transparent" />
                <div className="absolute top-4 right-4 w-12 h-12 rounded-xl flex items-center justify-center glass" style={{ borderColor: `${s.color}40` }}>
                  <s.icon className="w-6 h-6" style={{ color: s.color }} />
                </div>
              </div>
              <div className="p-6 space-y-4">
                <div><div className="text-xs font-medium tracking-wider uppercase text-[#8B95A8] mb-1">{s.subtitle}</div><h3 className="text-xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">{s.title}</h3></div>
                <p className="text-sm text-[#8B95A8] leading-relaxed">{s.desc}</p>
                <div className="flex flex-wrap gap-2">{s.features.map(f => <span key={f} className="px-3 py-1 text-xs rounded-full border border-[#4D6BFF]/15 text-[#8B95A8] glass">{f}</span>)}</div>
                <span className="inline-flex items-center gap-2 text-sm font-semibold" style={{ color: s.color }}>En savoir plus <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" /></span>
              </div>
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" style={{ background: `radial-gradient(circle at 50% 0%, ${s.color}10, transparent 70%)` }} />
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-8">
          {extra.map((s, i) => (
            <motion.div key={s.title} className="group p-6 rounded-xl glass hover:border-[#4D6BFF]/30 transition-all" initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: i * 0.1 }}>
              <s.icon className="w-8 h-8 text-[#4D6BFF] mb-4 group-hover:scale-110 transition-transform" />
              <h4 className="text-sm font-semibold text-[#E0E6F1] mb-1">{s.title}</h4><p className="text-xs text-[#8B95A8]">{s.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ===== NETWORK SECTION ===== */
function NetworkSection() {
  const cities = [
    { name: 'Dakar', x: 18, y: 50, size: 3 }, { name: 'Thies', x: 30, y: 42, size: 1.5 },
    { name: 'Saint-Louis', x: 18, y: 15, size: 2 }, { name: 'Tamba', x: 60, y: 40, size: 1.5 },
    { name: 'Ziguinchor', x: 12, y: 75, size: 1.5 }, { name: 'Kaolack', x: 38, y: 55, size: 2 },
    { name: 'Kolda', x: 45, y: 70, size: 1.5 }, { name: 'Matam', x: 65, y: 18, size: 1.5 },
  ];

  return (
    <section id="network" className="relative bg-[#050A14] py-28 overflow-hidden">
      <div className="absolute inset-0 opacity-[0.03]">
        <div className="w-full h-full" style={{ backgroundImage: 'linear-gradient(rgba(77,107,255,0.4) 1px, transparent 1px), linear-gradient(90deg, rgba(77,107,255,0.4) 1px, transparent 1px)', backgroundSize: '60px 60px' }} />
      </div>
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div className="space-y-8" initial={{ opacity: 0, x: -50 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }}>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#D4AF37]/30 glass"><Radio className="w-4 h-4 text-[#D4AF37]" /><span className="text-sm font-medium text-[#D4AF37] tracking-wider">Infrastructure Nationale</span></div>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">UN RESEAU NATIONAL<br /><span className="text-gradient-gold">D'ONDES ET DE LUMIERE</span></h2>
            <p className="text-lg text-[#8B95A8] leading-relaxed max-w-lg">Notre reseau fibre optique s'etend sur plus de 8,000 km a travers le Senegal, connectant les grandes metropoles aux zones rurales. Avec 4 cables sous-marins internationaux, nous relions l'Afrique au monde entier.</p>
            <div className="grid grid-cols-2 gap-4">
              {[{ icon: Zap, v: '8,000+', l: 'Km de fibre' }, { icon: Globe, v: '4', l: 'Cables sous-marins' }, { icon: Server, v: '3', l: 'Data Centers' }, { icon: Shield, v: 'TIER III', l: 'Certification' }].map((m, i) => (
                <div key={i} className="p-4 rounded-xl glass"><m.icon className="w-5 h-5 text-[#4D6BFF] mb-2" /><div className="text-xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">{m.v}</div><div className="text-xs text-[#8B95A8]">{m.l}</div></div>
              ))}
            </div>
          </motion.div>

          <motion.div className="relative" initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ duration: 1 }}>
            <svg viewBox="0 0 80 90" className="w-full h-auto max-h-[600px]">
              <defs>
                <filter id="glow-net"><feGaussianBlur stdDeviation="1.5" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
                <linearGradient id="lg1" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stopColor="#4D6BFF" /><stop offset="100%" stopColor="#D4AF37" /></linearGradient>
              </defs>
              {cities.map((c, i) => cities.slice(i + 1).map((c2, j) => {
                const dist = Math.sqrt((c.x - c2.x) ** 2 + (c.y - c2.y) ** 2);
                if (dist > 35) return null;
                const mx = (c.x + c2.x) / 2 + (Math.random() - 0.5) * 8;
                const my = (c.y + c2.y) / 2 + (Math.random() - 0.5) * 8;
                return <path key={`${i}-${j}`} d={`M ${c.x} ${c.y} Q ${mx} ${my} ${c2.x} ${c2.y}`} fill="none" stroke="url(#lg1)" strokeWidth="0.25" opacity="0.4" filter="url(#glow-net)" />;
              }))}
              {cities.map((c, i) => (
                <g key={c.name}>
                  <circle cx={c.x} cy={c.y} r={c.size} fill={i === 0 ? '#D4AF37' : '#4D6BFF'} filter="url(#glow-net)">
                    {i === 0 && <animate attributeName="r" values={`${c.size};${c.size + 1};${c.size}`} dur="3s" repeatCount="indefinite" />}
                  </circle>
                  <text x={c.x} y={c.y - c.size - 2} textAnchor="middle" fill="#8B95A8" fontSize="2.5" fontFamily="Space Grotesk" fontWeight="500">{c.name}</text>
                </g>
              ))}
              <circle cx={cities[0].x} cy={cities[0].y} r="6" fill="#D4AF37" opacity="0.15">
                <animate attributeName="r" values="6;8;6" dur="3s" repeatCount="indefinite" />
                <animate attributeName="opacity" values="0.15;0.05;0.15" dur="3s" repeatCount="indefinite" />
              </circle>
            </svg>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

/* ===== METRICS ===== */
function Metrics() {
  const metrics = [
    { icon: Users, value: '19M+', label: 'Utilisateurs actifs', detail: 'Dans 5 pays africains' },
    { icon: Globe, value: '150+', label: 'Pays connectes', detail: 'Via nos cables sous-marins' },
    { icon: TrendingUp, value: '99.99%', label: 'Disponibilite', detail: 'Garantie SLA entreprise' },
    { icon: Server, value: '8000+', label: 'Km fibre optique', detail: 'Couverture nationale' },
    { icon: Award, value: '40+', label: 'Ans d\'excellence', detail: 'Depuis 1985' },
    { icon: Clock, value: '24/7', label: 'Support client', detail: 'Assistance permanente' },
  ];

  return (
    <section className="relative bg-[#050A14] py-28 overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-[#4D6BFF]/3 blur-[150px] pointer-events-none" />
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12 relative z-10">
        <motion.div className="text-center mb-16 space-y-4" initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }}>
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#4D6BFF]/30 glass"><TrendingUp className="w-4 h-4 text-[#4D6BFF]" /><span className="text-sm font-medium text-[#4D6BFF] tracking-wider">Chiffres Cles</span></div>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">NOS <span className="text-gradient-gold">PERFORMANCES</span></h2>
          <p className="text-lg text-[#8B95A8] max-w-2xl mx-auto">Des chiffres qui temoignent de notre engagement pour l'excellence et la connectivite.</p>
        </motion.div>

        <div className="grid grid-cols-2 lg:grid-cols-3 gap-5">
          {metrics.map((m, i) => (
            <motion.div key={m.label} className="group relative p-6 lg:p-8 rounded-2xl glass hover:border-[#4D6BFF]/30 transition-all overflow-hidden" initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: i * 0.1 }}>
              <div className="absolute inset-0 shimmer opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="relative z-10">
                <m.icon className="w-8 h-8 text-[#4D6BFF] mb-4" />
                <div className="text-3xl lg:text-4xl font-bold text-[#E0E6F1] font-['Space_Grotesk'] mb-1">{m.value}</div>
                <div className="text-sm text-[#E0E6F1] font-medium mb-1">{m.label}</div>
                <div className="text-xs text-[#8B95A8]">{m.detail}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ===== ECOSYSTEM CARDS ===== */
function Ecosystem() {
  const portals = [
    { to: '/store', title: 'STORE', desc: 'Forfaits, telephones & accessoires', color: '#FF6B35', icon: CreditCard, img: '/p2-phones.jpg' },
    { to: '/islam', title: 'ISLAM', desc: 'Coran, prieres, Hadiths & Mawaaid', color: '#1B8A4C', icon: Globe, img: '/p2-mosque.jpg' },
    { to: '/miracle', title: 'MIRACLE', desc: 'Technologie au service de la foi', color: '#D4AF37', icon: Sparkles, img: '/p2-pattern.jpg' },
    { to: '/ia', title: 'IA', desc: 'Chatbot SENAI & Generateur d\'images', color: '#7B2D8E', icon: Zap, img: '/p4-neural.jpg' },
    { to: '/averoes', title: 'AVEROES', desc: 'Education, philosophie & savoir', color: '#8B4513', icon: Award, img: '/p3-manuscript.jpg' },
    { to: '/space', title: 'SPACE', desc: 'Satellites, ISS & Astronomie', color: '#00E5FF', icon: Radio, img: '/p5-aurora.jpg' },
    { to: '/alphabet', title: 'ALPHABET', desc: 'Apprentissage de l\'arabe', color: '#1B8A4C', icon: BookOpen, img: '/p2-quran.jpg' },
  ];

  return (
    <section className="relative bg-[#050A14] py-28 overflow-hidden">
      <div className="absolute top-0 right-0 w-[500px] h-[500px] rounded-full bg-[#D4AF37]/5 blur-[150px] pointer-events-none" />
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12 relative z-10">
        <motion.div className="text-center mb-16 space-y-4" initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }}>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">NOTRE <span className="text-gradient-gold">ECOSYSTEME</span></h2>
          <p className="text-lg text-[#8B95A8] max-w-2xl mx-auto">Decouvrez nos 8 portails dedies pour repondre a tous vos besoins numeriques, spirituels et educatifs.</p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {portals.map((p, i) => (
            <motion.div key={p.to} initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: i * 0.1 }}>
              <Link to={p.to} className="group relative block rounded-2xl overflow-hidden border border-white/8 bg-[#0B1426]/50 hover:border-white/20 transition-all duration-500">
                <div className="relative h-44 overflow-hidden">
                  <img src={p.img} alt="" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0B1426] via-[#0B1426]/60 to-transparent" />
                </div>
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" style={{ background: `radial-gradient(circle at 50% 0%, ${p.color}15, transparent 70%)` }} />
                <div className="relative z-10 p-6 -mt-8">
                  <div className="w-14 h-14 rounded-xl flex items-center justify-center mb-4 glass" style={{ borderColor: `${p.color}30` }}>
                    <p.icon className="w-7 h-7" style={{ color: p.color }} />
                  </div>
                  <h3 className="text-2xl font-bold text-[#E0E6F1] font-['Space_Grotesk'] mb-2">{p.title}</h3>
                  <p className="text-sm text-[#8B95A8] mb-4">{p.desc}</p>
                  <span className="inline-flex items-center gap-2 text-sm font-semibold" style={{ color: p.color }}>Explorer <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" /></span>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ===== TESTIMONIALS ===== */
function Testimonials() {
  const testimonials = [
    { name: 'Aminata Diallo', role: 'CEO, TechSahel', text: 'La fibre optique de Senegal Telecom a transforme notre entreprise. Un debit stable et un support technique toujours reactif.', stars: 5 },
    { name: 'Omar Faye', role: 'Directeur IT, Banque Nationale', text: 'Leur solution cloud Tier III nous a permis de migrer toute notre infrastructure en toute securite. Excellente experience.', stars: 5 },
    { name: 'Mariama Ndiaye', role: 'Entrepreneuse, Dakar', text: 'Aduna Money facilite mes transactions quotidiennes. Un service indispensable pour les entrepreneurs africains.', stars: 5 },
  ];

  return (
    <section className="relative bg-[#050A14] py-28">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <motion.div className="text-center mb-16" initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }}>
          <h2 className="text-4xl md:text-5xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">ILS NOUS FONT <span className="text-gradient-gold">CONFIANCE</span></h2>
        </motion.div>
        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <motion.div key={i} className="p-6 rounded-2xl glass space-y-4" initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: i * 0.1 }}>
              <div className="flex gap-1">{Array.from({ length: t.stars }).map((_, j) => <Star key={j} className="w-4 h-4 text-[#D4AF37] fill-[#D4AF37]" />)}</div>
              <p className="text-[#E0E6F1] italic leading-relaxed">"{t.text}"</p>
              <div className="pt-3 border-t border-white/5"><div className="text-sm font-semibold text-[#E0E6F1]">{t.name}</div><div className="text-xs text-[#8B95A8]">{t.role}</div></div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ===== FOOTER ===== */
function Footer() {
  const links = {
    Solutions: ['Fibre Optique', '5G Mobile', 'Cloud & Data', 'Aduna Money', 'Cybersecurite'],
    Entreprise: ['Qui sommes-nous', 'Nos filiales', 'Rapports financiers', 'Carrieres', 'Presse'],
    Support: ['Assistance technique', 'Espace client', 'Couverture reseau', 'FAQ', 'Contact'],
  };

  return (
    <footer className="bg-[#02050D] pt-24 pb-8 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-[#4D6BFF]/50 to-transparent" />
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8 mb-16">
          <div className="col-span-2 md:col-span-4 lg:col-span-2 space-y-6">
            <Link to="/" className="flex items-center gap-3">
              <div className="relative w-12 h-12 flex items-center justify-center"><div className="absolute inset-0 bg-[#4D6BFF] rounded-lg rotate-45 opacity-80" /><Signal className="relative z-10 w-6 h-6 text-white" /></div>
              <div className="flex flex-col"><span className="text-xl font-bold tracking-wider text-[#E0E6F1] font-['Space_Grotesk']">SENEGAL</span><span className="text-xs tracking-[0.3em] text-[#4D6BFF] font-medium -mt-1">TELECOM</span></div>
            </Link>
            <p className="text-sm text-[#8B95A8] leading-relaxed max-w-sm">Leader des telecommunications en Afrique de l'Ouest depuis 1985. Connectant le Senegal, le Mali, la Guinee, la Guinee-Bissau et la Sierra Leone.</p>
            <div className="space-y-2">
              <div className="flex items-center gap-3 text-sm text-[#8B95A8]"><Phone className="w-4 h-4 text-[#4D6BFF]" /><span>+221 33 839 00 00</span></div>
              <div className="flex items-center gap-3 text-sm text-[#8B95A8]"><MapPin className="w-4 h-4 text-[#4D6BFF]" /><span>Dakar, Senegal</span></div>
            </div>
          </div>
          {Object.entries(links).map(([cat, items]) => (
            <div key={cat} className="space-y-4">
              <h4 className="text-sm font-semibold tracking-wider uppercase text-[#E0E6F1]">{cat}</h4>
              <ul className="space-y-3">{items.map(l => <li key={l}><a href="#" className="text-sm text-[#8B95A8] hover:text-[#E0E6F1] transition-colors">{l}</a></li>)}</ul>
            </div>
          ))}
        </div>

        <div className="p-6 rounded-2xl glass mb-12">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
            <div><h4 className="text-lg font-semibold text-[#E0E6F1] mb-1">Restez informe</h4><p className="text-sm text-[#8B95A8]">Recevez nos actualites et offres exclusives.</p></div>
            <div className="flex gap-3">
              <input type="email" placeholder="Votre email" className="px-4 py-3 rounded-xl bg-[#050A14] border border-[#4D6BFF]/20 text-[#E0E6F1] placeholder-[#8B95A8] text-sm focus:outline-none focus:border-[#4D6BFF] w-64" />
              <button className="px-6 py-3 bg-[#4D6BFF] text-white text-sm font-semibold rounded-xl hover:bg-[#3D5BE8] transition-colors">S'abonner</button>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-[#4D6BFF]/10 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <p className="text-xs text-[#8B95A8]">&copy; 2025 SENEGAL TELECOM. Tous droits reserves.</p>
          <div className="flex gap-6"><a href="#" className="text-xs text-[#8B95A8] hover:text-[#E0E6F1] transition-colors">Confidentialite</a><a href="#" className="text-xs text-[#8B95A8] hover:text-[#E0E6F1] transition-colors">Conditions</a><a href="#" className="text-xs text-[#8B95A8] hover:text-[#E0E6F1] transition-colors">Mentions legales</a></div>
        </div>
      </div>
    </footer>
  );
}

/* ===== HOME PAGE ===== */
export default function Home() {
  return (
    <div className="min-h-screen bg-[#050A14] text-[#E0E6F1] overflow-x-hidden">
      <Navbar />
      <main><Hero /><Services /><NetworkSection /><Metrics /><Ecosystem /><Testimonials /></main>
      <Footer />
    </div>
  );
}
