import { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { User, CreditCard, Wifi, Receipt, Settings, LogOut, Bell, TrendingUp, CheckCircle, ChevronRight } from 'lucide-react';

const invoices = [
  { id: 'FAC-2025-001', date: '15 Jan 2025', amount: 25000, status: 'Payée', service: 'Box Fibre 1Gbps' },
  { id: 'FAC-2024-012', date: '15 Déc 2024', amount: 15000, status: 'Payée', service: 'Forfait Illimite 5G' },
  { id: 'FAC-2024-011', date: '15 Nov 2024', amount: 45000, status: 'Payée', service: 'Ecouteurs ST Pro' },
];

const services = [
  { name: 'Box Fibre 1Gbps', status: 'Actif', icon: Wifi, usage: '87%', color: '#4D6BFF' },
  { name: 'Forfait Illimite 5G', status: 'Actif', icon: Wifi, usage: '64%', color: '#00E5A0' },
  { name: 'Cloud 50GB', status: 'Actif', icon: Wifi, usage: '42%', color: '#D4AF37' },
];

const notifications = [
  { title: 'Facture disponible', desc: 'Votre facture de Janvier 2025 est disponible.', time: 'Il y a 2h', read: false },
  { title: 'Maintenance réseau', desc: 'Maintenance prévue le 28 Janvier à 2h du matin.', time: 'Il y a 1j', read: false },
  { title: 'Promotion', desc: 'Nouveau forfait étudiant -33% de remise.', time: 'Il y a 3j', read: true },
];

export default function EspaceClient() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && password) setLoggedIn(true);
  };

  if (!loggedIn) {
    return (
      <div className="min-h-screen bg-[#050A14] text-[#E0E6F1] flex items-center justify-center">
        <Navbar />
        <motion.div className="w-full max-w-md p-8 rounded-2xl glass-strong border border-[#4D6BFF]/20 mt-20" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }}>
          <div className="text-center mb-8">
            <div className="w-16 h-16 rounded-xl bg-[#4D6BFF]/20 flex items-center justify-center mx-auto mb-4">
              <User className="w-8 h-8 text-[#4D6BFF]" />
            </div>
            <h1 className="text-2xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">Espace Client</h1>
            <p className="text-sm text-[#8B95A8] mt-1">Connectez-vous pour gérer votre compte</p>
          </div>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="text-sm text-[#8B95A8] mb-1 block">Email ou Numéro</label>
              <input type="text" value={email} onChange={e => setEmail(e.target.value)} placeholder="client@senegaltelecom.sn" className="w-full px-4 py-3 rounded-xl bg-[#0B1426] border border-[#4D6BFF]/20 text-[#E0E6F1] placeholder-[#8B95A8] text-sm focus:outline-none focus:border-[#4D6BFF]" />
            </div>
            <div>
              <label className="text-sm text-[#8B95A8] mb-1 block">Mot de passe</label>
              <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" className="w-full px-4 py-3 rounded-xl bg-[#0B1426] border border-[#4D6BFF]/20 text-[#E0E6F1] placeholder-[#8B95A8] text-sm focus:outline-none focus:border-[#4D6BFF]" />
            </div>
            <button type="submit" className="w-full py-3 rounded-xl bg-[#4D6BFF] text-white font-semibold hover:bg-[#3D5BE8] transition-all">
              Se Connecter
            </button>
          </form>
          <div className="mt-6 text-center space-y-2">
            <a href="#" className="text-sm text-[#4D6BFF] hover:underline">Mot de passe oublié ?</a>
            <p className="text-sm text-[#8B95A8]">Pas encore client ? <Link to="/store" className="text-[#4D6BFF] hover:underline">Découvrir nos offres</Link></p>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050A14] text-[#E0E6F1]">
      <Navbar />
      <div className="pt-28 pb-12 max-w-[1440px] mx-auto px-6 lg:px-12">
        <div className="grid lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-2">
            <div className="p-6 rounded-2xl glass mb-4">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full bg-[#4D6BFF]/20 flex items-center justify-center">
                  <User className="w-6 h-6 text-[#4D6BFF]" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-[#E0E6F1]">Moussa Diallo</div>
                  <div className="text-xs text-[#8B95A8]">+221 77 XXX XX XX</div>
                </div>
              </div>
              <div className="w-full h-px bg-[#4D6BFF]/10" />
            </div>

            {[{ k: 'dashboard', l: 'Tableau de bord', i: TrendingUp }, { k: 'factures', l: 'Factures', i: Receipt }, { k: 'services', l: 'Mes Services', i: Wifi }, { k: 'parametres', l: 'Paramètres', i: Settings }].map(t => (
              <button key={t.k} onClick={() => setActiveTab(t.k)} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${activeTab === t.k ? 'bg-[#4D6BFF]/15 text-[#4D6BFF] border border-[#4D6BFF]/20' : 'text-[#8B95A8] hover:text-[#E0E6F1] hover:bg-white/5'}`}>
                <t.i className="w-4 h-4" />{t.l}
              </button>
            ))}
            <button onClick={() => setLoggedIn(false)} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-[#8B95A8] hover:text-[#E0E6F1] hover:bg-white/5 transition-all">
              <LogOut className="w-4 h-4" />Déconnexion
            </button>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {activeTab === 'dashboard' && (
              <div className="space-y-6">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[{ label: 'Solde', value: '125,000 FCFA', icon: CreditCard, color: '#4D6BFF' }, { label: 'Consommation Data', value: '64 Go / 100 Go', icon: Wifi, color: '#00E5A0' }, { label: 'Factures', value: '3 impayées', icon: Receipt, color: '#FF6B35' }, { label: 'Notifications', value: '2 nouvelles', icon: Bell, color: '#D4AF37' }].map((s, i) => (
                    <motion.div key={s.label} className="p-5 rounded-xl glass" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
                      <s.icon className="w-5 h-5 mb-2" style={{ color: s.color }} />
                      <div className="text-lg font-bold text-[#E0E6F1]">{s.value}</div>
                      <div className="text-xs text-[#8B95A8]">{s.label}</div>
                    </motion.div>
                  ))}
                </div>

                <div className="grid lg:grid-cols-2 gap-6">
                  <div className="p-6 rounded-2xl glass">
                    <h3 className="text-lg font-bold text-[#E0E6F1] font-['Space_Grotesk'] mb-4">Notifications récentes</h3>
                    <div className="space-y-3">
                      {notifications.map((n, i) => (
                        <div key={i} className="flex items-start gap-3 p-3 rounded-xl bg-[#0B1426]/50">
                          <div className={`w-2 h-2 rounded-full mt-2 ${n.read ? 'bg-[#8B95A8]' : 'bg-[#4D6BFF] animate-pulse'}`} />
                          <div className="flex-1">
                            <div className="text-sm font-medium text-[#E0E6F1]">{n.title}</div>
                            <div className="text-xs text-[#8B95A8]">{n.desc}</div>
                          </div>
                          <span className="text-xs text-[#8B95A8]">{n.time}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="p-6 rounded-2xl glass">
                    <h3 className="text-lg font-bold text-[#E0E6F1] font-['Space_Grotesk'] mb-4">Utilisation mensuelle</h3>
                    <div className="space-y-4">
                      {services.map(s => (
                        <div key={s.name}>
                          <div className="flex justify-between text-sm mb-1"><span className="text-[#E0E6F1]">{s.name}</span><span className="text-[#8B95A8]">{s.usage}</span></div>
                          <div className="w-full h-2 bg-[#0B1426] rounded-full overflow-hidden"><div className="h-full rounded-full" style={{ width: s.usage, backgroundColor: s.color }} /></div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'factures' && (
              <div className="p-6 rounded-2xl glass">
                <h3 className="text-lg font-bold text-[#E0E6F1] font-['Space_Grotesk'] mb-4">Historique des factures</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead><tr className="text-[#8B95A8] text-left border-b border-[#4D6BFF]/10"><th className="pb-3">N° Facture</th><th className="pb-3">Date</th><th className="pb-3">Service</th><th className="pb-3">Montant</th><th className="pb-3">Statut</th><th className="pb-3"></th></tr></thead>
                    <tbody className="divide-y divide-[#4D6BFF]/5">
                      {invoices.map(inv => (
                        <tr key={inv.id} className="hover:bg-white/5 transition-colors">
                          <td className="py-4 font-mono text-[#4D6BFF]">{inv.id}</td>
                          <td className="py-4 text-[#8B95A8]">{inv.date}</td>
                          <td className="py-4">{inv.service}</td>
                          <td className="py-4 font-bold">{inv.amount.toLocaleString()} FCFA</td>
                          <td className="py-4"><span className="px-2 py-1 rounded-full text-xs bg-[#00E5A0]/10 text-[#00E5A0] border border-[#00E5A0]/20">{inv.status}</span></td>
                          <td className="py-4"><button className="text-[#4D6BFF] hover:underline text-xs">Télécharger</button></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'services' && (
              <div className="space-y-4">
                {services.map(s => (
                  <div key={s.name} className="p-6 rounded-2xl glass flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${s.color}15` }}><s.icon className="w-6 h-6" style={{ color: s.color }} /></div>
                      <div><div className="text-sm font-semibold text-[#E0E6F1]">{s.name}</div><div className="text-xs text-[#00E5A0] flex items-center gap-1"><CheckCircle className="w-3 h-3" />{s.status}</div></div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-[#8B95A8]" />
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'parametres' && (
              <div className="p-6 rounded-2xl glass space-y-6">
                <h3 className="text-lg font-bold text-[#E0E6F1] font-['Space_Grotesk']">Paramètres du compte</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div><label className="text-sm text-[#8B95A8] mb-1 block">Nom complet</label><input type="text" defaultValue="Moussa Diallo" className="w-full px-4 py-3 rounded-xl bg-[#0B1426] border border-[#4D6BFF]/20 text-[#E0E6F1] text-sm focus:outline-none focus:border-[#4D6BFF]" /></div>
                  <div><label className="text-sm text-[#8B95A8] mb-1 block">Email</label><input type="email" defaultValue="moussa.diallo@email.com" className="w-full px-4 py-3 rounded-xl bg-[#0B1426] border border-[#4D6BFF]/20 text-[#E0E6F1] text-sm focus:outline-none focus:border-[#4D6BFF]" /></div>
                  <div><label className="text-sm text-[#8B95A8] mb-1 block">Téléphone</label><input type="tel" defaultValue="+221 77 123 45 67" className="w-full px-4 py-3 rounded-xl bg-[#0B1426] border border-[#4D6BFF]/20 text-[#E0E6F1] text-sm focus:outline-none focus:border-[#4D6BFF]" /></div>
                  <div><label className="text-sm text-[#8B95A8] mb-1 block">Ville</label><input type="text" defaultValue="Dakar" className="w-full px-4 py-3 rounded-xl bg-[#0B1426] border border-[#4D6BFF]/20 text-[#E0E6F1] text-sm focus:outline-none focus:border-[#4D6BFF]" /></div>
                </div>
                <button className="px-6 py-3 rounded-xl bg-[#4D6BFF] text-white font-semibold hover:bg-[#3D5BE8] transition-all">Sauvegarder les changements</button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
