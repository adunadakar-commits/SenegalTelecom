import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { BookOpen, Compass, Clock, Sun, Moon, Play, Heart, Calendar, Volume2, Pause, Bookmark, Share2, GraduationCap } from 'lucide-react';

const prayerTimes = [
  { name: 'Fajr', time: '05:42', rakats: '2+2', icon: Sun },
  { name: 'Dhuhr', time: '13:15', rakats: '4+4+2', icon: Sun },
  { name: 'Asr', time: '16:45', rakats: '4+4', icon: Sun },
  { name: 'Maghrib', time: '19:28', rakats: '3+2', icon: Moon },
  { name: 'Isha', time: '20:52', rakats: '4+4+2+3+2', icon: Moon },
];

const surahs = [
  { name: 'Al-Fatiha', arabic: 'الفاتحة', verses: 7, meaning: "L'Ouverture", reciter: 'Sheikh Mishary' },
  { name: 'Al-Baqarah', arabic: 'البقرة', verses: 286, meaning: 'La Vache', reciter: 'Sheikh Abdul Basit' },
  { name: "Al-Imran", arabic: 'آل عمران', verses: 200, meaning: 'La Famille de Imran', reciter: 'Sheikh Saad Al-Ghamidi' },
  { name: 'An-Nisa', arabic: 'النساء', verses: 176, meaning: 'Les Femmes', reciter: 'Sheikh Al-Minshawi' },
  { name: 'Al-Ma\'idah', arabic: 'المائدة', verses: 120, meaning: 'La Table Servie', reciter: 'Sheikh Mishary' },
  { name: 'Al-Ikhlas', arabic: 'الإخلاص', verses: 4, meaning: 'Le Monotheisme Pur', reciter: 'Sheikh Al-Afasy' },
  { name: 'Al-Falaq', arabic: 'الفلق', verses: 5, meaning: "L'Aube", reciter: 'Sheikh Al-Afasy' },
  { name: 'An-Nas', arabic: 'الناس', verses: 6, meaning: 'Les Humains', reciter: 'Sheikh Al-Afasy' },
];

const hadiths = [
  { text: 'Les actes ne valent que par leur intention.', source: 'Bukhari & Muslim', narrator: 'Omar ibn Al-Khattab (RA)', category: 'Sincerite' },
  { text: 'Le meilleur d\'entre vous est celui qui apprend le Coran et l\'enseigne.', source: 'Bukhari', narrator: 'Uthman ibn Affan (RA)', category: 'Savoir' },
  { text: 'Ne vous mettez pas en colere.', source: 'Bukhari', narrator: 'Abu Hurayra (RA)', category: 'Sagesse' },
  { text: 'Le musulman est celui dont les autres musulmans sont a l\'abri de sa langue et de sa main.', source: 'Bukhari & Muslim', narrator: 'Abdullah ibn Amr (RA)', category: 'Fraternite' },
  { text: 'Allah n\'a pas fait descendre de maladie sans avoir fait descendre son remede.', source: 'Bukhari', narrator: 'Abu Hurayra (RA)', category: 'Medecine' },
];

const mawaaid = [
  { title: 'Mawaid 1: La sincerite de l\'intention', desc: "L'intention sincere est la base de tout acte d'adoration. Le Prophete (PSL) a dit : 'Les actes ne valent que par leur intention.'", date: '12 Ramadan' },
  { title: 'Mawaid 2: La patience dans l\'adversite', desc: "Allah dit dans le Coran : 'O vous qui croyez! Cherchez secours dans l'endurance et la Salat. Car Allah est avec ceux qui patientent.'", date: '13 Ramadan' },
  { title: 'Mawaid 3: La gratitude envers Allah', desc: "Si vous remerciez, Je vous accroiterai. La gratitude est la cle de l\'abondance dans la vie du croyant.", date: '14 Ramadan' },
  { title: 'Mawaid 4: La bienfaisance envers les parents', desc: "Ton Seigneur a decrete de ne Lui adorer que Lui et de bien traiter tes parents. C\'est le droit supreme apres le Tawhid.", date: '15 Ramadan' },
  { title: 'Mawaid 5: L\'importance du savoir', desc: "Le savoir est la lumiere. Chercher le savoir est un devoir pour chaque musulman, homme ou femme.", date: '16 Ramadan' },
  { title: 'Mawaid 6: La purification du coeur', desc: "Le croyant est celui qui purifie continuellement son coeur des maladies spirituelles : jalousie, orgueil, rancune.", date: '17 Ramadan' },
];

export default function Islam() {
  const [activeSurah, setActiveSurah] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [activeTab, setActiveTab] = useState('coran');

  useEffect(() => { const timer = setInterval(() => setCurrentTime(new Date()), 1000); return () => clearInterval(timer); }, []);

  const nextPrayer = prayerTimes.find(p => { const [h, m] = p.time.split(':').map(Number); return h * 60 + m > currentTime.getHours() * 60 + currentTime.getMinutes(); }) || prayerTimes[0];

  return (
    <div className="min-h-screen bg-[#0a1f14] text-[#F5F5DC]">
      <Navbar />
      {/* HERO */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0"><img src="/p2-quran.jpg" alt="" className="w-full h-full object-cover opacity-40" /><div className="absolute inset-0 bg-gradient-to-b from-[#0a1f14] via-[#0a1f14]/80 to-[#0a1f14]" /></div>
        <div className="relative z-10 max-w-[1440px] mx-auto px-6 lg:px-12 text-center">
          <motion.div className="space-y-6" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#1B8A4C]/30 glass"><Moon className="w-4 h-4 text-[#D4AF37]" /><span className="text-sm font-medium text-[#D4AF37] tracking-wider">Portail Islamique — SENEGAL TELECOM</span></div>
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold font-['Space_Grotesk']">SENEGAL TELECOM <span className="text-gradient-islam">ISLAM</span></h1>
            <p className="text-xl text-[#8B95A8] max-w-2xl mx-auto italic leading-relaxed">"Guide-nous sur le droit chemin, le chemin de ceux que Tu as combles de faveurs, non pas le chemin de ceux qui ont encouru Ta colere, ni celui des egares." — Al-Fatiha, 1:6-7</p>
          </motion.div>
        </div>
      </section>

      {/* PRAYER TIMES */}
      <section className="py-12">
        <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
          <motion.div className="grid lg:grid-cols-3 gap-8" initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }}>
            <div className="lg:col-span-1 p-8 rounded-2xl border border-[#1B8A4C]/20 glass-strong text-center space-y-5">
              <Clock className="w-10 h-10 text-[#D4AF37] mx-auto" />
              <div><div className="text-sm text-[#8B95A8] uppercase tracking-wider mb-2">Prochaine Priere — Dakar</div><div className="text-4xl font-bold text-[#D4AF37] font-['Space_Grotesk']">{nextPrayer.name}</div></div>
              <div className="text-6xl font-bold text-[#E0E6F1] font-mono">{nextPrayer.time}</div>
              <div className="text-sm text-[#8B95A8]">{currentTime.toLocaleDateString('fr-FR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</div>
              <div className="w-full h-px bg-[#1B8A4C]/20" />
              <div className="text-xs text-[#8B95A8]">Rakat: {nextPrayer.rakats}</div>
            </div>
            <div className="lg:col-span-2 grid grid-cols-5 gap-3">
              {prayerTimes.map(p => (
                <div key={p.name} className={`p-4 rounded-xl border text-center space-y-3 transition-all ${p.name === nextPrayer.name ? 'border-[#D4AF37]/50 bg-[#D4AF37]/10' : 'border-[#1B8A4C]/15 glass'}`}>
                  <p.icon className={`w-6 h-6 mx-auto ${p.name === nextPrayer.name ? 'text-[#D4AF37]' : 'text-[#1B8A4C]'}`} />
                  <div className="text-sm font-bold text-[#E0E6F1]">{p.name}</div>
                  <div className="text-lg font-bold text-[#D4AF37]">{p.time}</div>
                  <div className="text-[10px] text-[#8B95A8]">{p.rakats}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* QURAN + TABS */}
      <section className="py-12">
        <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
          <div className="flex flex-wrap gap-3 mb-8 justify-center">
            {[{ k: 'coran', l: 'Coran', i: BookOpen }, { k: 'hadith', l: 'Hadiths', i: Heart }, { k: 'mawaaid', l: 'Mawaaid', i: Calendar }].map(t => (
              <button key={t.k} onClick={() => setActiveTab(t.k)} className={`flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-medium transition-all ${activeTab === t.k ? 'bg-[#1B8A4C] text-white' : 'glass text-[#8B95A8] hover:text-[#E0E6F1]'}`}><t.i className="w-4 h-4" />{t.l}</button>
            ))}
            <Link to="/alphabet" className="flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-medium transition-all glass text-[#D4AF37] hover:bg-[#D4AF37]/20 border border-[#D4AF37]/30">
              <GraduationCap className="w-4 h-4" />Alphabet Arabe
            </Link>
          </div>

          {/* CORAN */}
          {activeTab === 'coran' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid lg:grid-cols-5 gap-8">
              <div className="lg:col-span-2 space-y-2 max-h-[500px] overflow-y-auto pr-2">
                {surahs.map((s, i) => (
                  <button key={s.name} onClick={() => setActiveSurah(i)} className={`w-full flex items-center gap-4 p-4 rounded-xl border transition-all text-left ${activeSurah === i ? 'border-[#D4AF37]/50 bg-[#D4AF37]/10' : 'border-[#1B8A4C]/15 glass hover:border-[#1B8A4C]/30'}`}>
                    <div className="w-10 h-10 rounded-lg bg-[#1B8A4C]/20 flex items-center justify-center text-[#D4AF37] font-bold text-sm">{i + 1}</div>
                    <div className="flex-1 min-w-0"><div className="text-sm font-semibold text-[#E0E6F1] truncate">{s.name}</div><div className="text-xs text-[#8B95A8]">{s.meaning} — {s.verses} versets</div></div>
                    <div className="text-lg text-[#D4AF37] arabic font-bold shrink-0">{s.arabic}</div>
                  </button>
                ))}
              </div>
              <div className="lg:col-span-3 p-8 rounded-2xl border border-[#1B8A4C]/20 glass-strong flex flex-col items-center justify-center space-y-6">
                <div className="w-full h-48 rounded-xl overflow-hidden"><img src="/p2-quran.jpg" alt="" className="w-full h-full object-cover" /></div>
                <div className="text-center space-y-3">
                  <div className="text-4xl text-[#D4AF37] arabic font-bold">{surahs[activeSurah].arabic}</div>
                  <div className="text-2xl text-[#E0E6F1] font-bold font-['Space_Grotesk']">{surahs[activeSurah].name}</div>
                  <div className="text-sm text-[#8B95A8]">{surahs[activeSurah].meaning} — {surahs[activeSurah].verses} versets</div>
                  <div className="text-xs text-[#D4AF37]">Recitateur: {surahs[activeSurah].reciter}</div>
                </div>
                <div className="w-full h-1.5 bg-[#1B8A4C]/20 rounded-full overflow-hidden"><div className="h-full w-1/3 bg-gradient-to-r from-[#1B8A4C] to-[#D4AF37] rounded-full" /></div>
                <div className="flex items-center gap-4">
                  <button onClick={() => setIsPlaying(!isPlaying)} className="w-16 h-16 rounded-full bg-[#D4AF37] text-[#0a1f14] flex items-center justify-center hover:bg-[#c9a030] transition-all active:scale-95">
                    {isPlaying ? <Pause className="w-7 h-7" /> : <Play className="w-7 h-7 ml-1" />}
                  </button>
                  <button className="w-12 h-12 rounded-full glass flex items-center justify-center"><Volume2 className="w-5 h-5 text-[#D4AF37]" /></button>
                  <button className="w-12 h-12 rounded-full glass flex items-center justify-center"><Bookmark className="w-5 h-5 text-[#D4AF37]" /></button>
                  <button className="w-12 h-12 rounded-full glass flex items-center justify-center"><Share2 className="w-5 h-5 text-[#D4AF37]" /></button>
                </div>
              </div>
            </motion.div>
          )}

          {/* HADITHS */}
          {activeTab === 'hadith' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
              {hadiths.map((h, i) => (
                <motion.div key={i} className="p-6 rounded-2xl border border-[#1B8A4C]/15 glass space-y-4" initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}>
                  <div className="flex items-center justify-between"><Heart className="w-5 h-5 text-[#D4AF37]" /><span className="px-2 py-0.5 rounded-full text-[10px] border border-[#D4AF37]/20 text-[#D4AF37]">{h.category}</span></div>
                  <p className="text-[#E0E6F1] italic leading-relaxed text-lg">"{h.text}"</p>
                  <div className="pt-3 border-t border-[#1B8A4C]/10"><div className="text-sm text-[#8B95A8]">{h.source}</div><div className="text-xs text-[#D4AF37]">{h.narrator}</div></div>
                </motion.div>
              ))}
            </motion.div>
          )}

          {/* MAWAID */}
          {activeTab === 'mawaaid' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
              {mawaaid.map((m, i) => (
                <motion.div key={i} className="p-6 rounded-2xl border border-[#1B8A4C]/15 glass space-y-3" initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}>
                  <div className="flex items-center justify-between"><Calendar className="w-5 h-5 text-[#D4AF37]" /><span className="text-xs text-[#8B95A8] px-2 py-0.5 rounded-full glass">{m.date}</span></div>
                  <h4 className="text-lg font-bold text-[#D4AF37] font-['Space_Grotesk']">{m.title}</h4>
                  <p className="text-sm text-[#8B95A8] leading-relaxed">{m.desc}</p>
                </motion.div>
              ))}
            </motion.div>
          )}
        </div>
      </section>

      {/* QIBLA */}
      <section className="py-12 pb-24">
        <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
          <div className="grid lg:grid-cols-2 gap-8">
            <motion.div className="p-8 rounded-2xl border border-[#D4AF37]/20 glass-strong text-center space-y-5" initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }}>
              <Compass className="w-14 h-14 text-[#D4AF37] mx-auto" />
              <h3 className="text-2xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">Direction Qibla</h3>
              <p className="text-sm text-[#8B95A8]">Depuis Dakar, Senegal</p>
              <div className="text-5xl font-bold text-[#D4AF37] font-['Space_Grotesk']">77° NE</div>
              <div className="relative w-32 h-32 rounded-full border-2 border-[#D4AF37]/30 mx-auto flex items-center justify-center">
                <div className="absolute top-2 text-xs text-[#D4AF37] font-bold">N</div>
                <div className="absolute bottom-2 text-xs text-[#8B95A8]">S</div>
                <div className="absolute left-2 text-xs text-[#8B95A8]">W</div>
                <div className="absolute right-2 text-xs text-[#8B95A8]">E</div>
                <Compass className="w-14 h-14 text-[#D4AF37] transition-transform duration-1000" style={{ transform: 'rotate(77deg)' }} />
              </div>
            </motion.div>
            <motion.div className="p-8 rounded-2xl border border-[#1B8A4C]/20 glass-strong flex flex-col items-center justify-center space-y-4" initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }}>
              <img src="/p2-mosque.jpg" alt="Mosquee de Touba" className="w-full h-48 rounded-xl object-cover" />
              <div className="text-center"><h4 className="text-lg font-bold text-[#E0E6F1] font-['Space_Grotesk']">Grande Mosquee de Touba</h4><p className="text-sm text-[#8B95A8]">Point de reference spirituel du Senegal</p></div>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
}
