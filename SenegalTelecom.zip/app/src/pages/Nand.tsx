/* Nand.tsx - Wolof Language Learning Portal */
import { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import { motion } from 'framer-motion';
import { BookOpen, Headphones, Trophy, Volume2, Pause, ChevronRight, Star, ArrowRight, GraduationCap, CheckCircle, XCircle, RotateCcw, Languages, Music } from 'lucide-react';

interface Lesson {
  id: number;
  title: string;
  titleWo: string;
  category: string;
  difficulty: string;
  phrases: { wo: string; fr: string; context?: string }[];
  vocabulary: { wo: string; fr: string; type: string }[];
  quiz: { question: string; options: string[]; correct: number }[];
  audioUrl?: string;
}

const lessons: Lesson[] = [
  {
    id: 1, title: 'Salutations', titleWo: 'Taalif', category: 'Basique', difficulty: 'Débutant',
    phrases: [
      { wo: 'Na nga def', fr: 'Comment vas-tu?', context: 'Salutation informelle' },
      { wo: 'Maangi fi', fr: 'Je vais bien', context: 'Réponse standard' },
      { wo: 'Naka ngon si rewum?', fr: 'Comment est le pays?', context: 'Demander des nouvelles' },
      { wo: 'Jam tan?', fr: 'Quoi de neuf?', context: 'Familier' },
      { wo: 'Ngoon', fr: 'Bienvenue', context: 'Accueillir' },
      { wo: 'Ba beneen yoon', fr: 'À la prochaine', context: 'Au revoir' }
    ],
    vocabulary: [
      { wo: 'Sama', fr: 'Mon/Ma', type: 'possessif' }, { wo: 'Sa', fr: 'Ton/Ta', type: 'possessif' },
      { wo: 'Nga', fr: 'Tu (présent)', type: 'pronom' }, { wo: 'Maa', fr: 'Je', type: 'pronom' },
      { wo: 'Fi', fr: 'Ici', type: 'adverbe' }, { wo: 'Dégg', fr: 'Entendre/Comprendre', type: 'verbe' }
    ],
    quiz: [
      { question: 'Comment dit-on "Comment vas-tu?" en wolof?', options: ['Maangi fi', 'Na nga def', 'Ngoon', 'Jam tan?'], correct: 1 },
      { question: 'Que signifie "Maangi fi"?', options: ['Je vais bien', 'Bonjour', 'Au revoir', 'Merci'], correct: 0 }
    ]
  },
  {
    id: 2, title: 'Famille', titleWo: 'Waa Kër', category: 'Basique', difficulty: 'Débutant',
    phrases: [
      { wo: 'Sama jàdd', fr: 'Mon père', context: 'Formel' },
      { wo: 'Sama ndey', fr: 'Ma mère', context: 'Affectueux' },
      { wo: 'Sama mbok', fr: 'Mon frère/sœur', context: 'Général' },
      { wo: 'Sama ndongo', fr: 'Mon ami', context: 'Camaraderie' },
      { wo: 'Waa kër', fr: 'La famille', context: 'Collectif' },
      { wo: 'Ndéwénal', fr: 'Les enfants', context: 'Pluriel' }
    ],
    vocabulary: [
      { wo: 'Kër', fr: 'Maison', type: 'nom' }, { wo: 'Waa', fr: 'Personne', type: 'nom' },
      { wo: 'Jàdd', fr: 'Père', type: 'nom' }, { wo: 'Ndey', fr: 'Mère', type: 'nom' },
      { wo: 'Ndongo', fr: 'Ami', type: 'nom' }, { wo: 'Mbok', fr: 'Fratrie', type: 'nom' }
    ],
    quiz: [
      { question: 'Que signifie "Waa Kër"?', options: ['Les voisins', 'La famille', 'Les amis', 'Le village'], correct: 1 },
      { question: 'Comment dit-on "Mon père"?', options: ['Sama ndey', 'Sama jàdd', 'Sama mbok', 'Sama ndongo'], correct: 1 }
    ]
  },
  {
    id: 3, title: 'Nourriture', titleWo: 'Lekk', category: 'Quotidien', difficulty: 'Débutant',
    phrases: [
      { wo: 'Dama xam-xam', fr: 'J\'ai faim', context: 'Expression courante' },
      { wo: 'Dama maar', fr: 'J\'ai soif', context: 'Expression courante' },
      { wo: 'Lekkal ma', fr: 'Mange avec moi', context: 'Invitation' },
      { wo: 'Sa wàcc na', fr: 'Bon appétit', context: 'Formule de politesse' },
      { wo: 'Ndox mi dafay tang', fr: 'L\'eau est chaude', context: 'Description' },
      { wo: 'Ci bés mi dana lekk ceebu jën', fr: 'Aujourd\'hui on mange du thieboudienne', context: 'Plat national' }
    ],
    vocabulary: [
      { wo: 'Lekk', fr: 'Manger', type: 'verbe' }, { wo: 'Naan', fr: 'Boire', type: 'verbe' },
      { wo: 'Ceeb', fr: 'Riz', type: 'nom' }, { wo: 'Jën', fr: 'Poisson', type: 'nom' },
      { wo: 'Ndox', fr: 'Eau', type: 'nom' }, { wo: 'Suuker', fr: 'Sucre', type: 'nom' }
    ],
    quiz: [
      { question: 'Comment dit-on "J\'ai faim"?', options: ['Dama maar', 'Dama xam-xam', 'Lekkal ma', 'Sa wàcc na'], correct: 1 },
      { question: 'Que signifie "Ceeb"?', options: ['Pain', 'Riz', 'Eau', 'Poisson'], correct: 1 }
    ]
  },
  {
    id: 4, title: 'Nombres', titleWo: 'Lim', category: 'Basique', difficulty: 'Débutant',
    phrases: [
      { wo: 'Benna', fr: 'Un', context: 'Base' },
      { wo: 'Ñaar', fr: 'Deux', context: 'Base' },
      { wo: 'Ñeent', fr: 'Quatre', context: 'Base' },
      { wo: 'Juróom', fr: 'Cinq', context: 'Base' },
      { wo: 'Juróom-benna', fr: 'Six', context: '5+1' },
      { wo: 'Fukk ak ñaar', fr: 'Douze', context: '10+2' }
    ],
    vocabulary: [
      { wo: 'Benna', fr: '1', type: 'nombre' }, { wo: 'Ñaar', fr: '2', type: 'nombre' },
      { wo: 'Ñeent', fr: '4', type: 'nombre' }, { wo: 'Juróom', fr: '5', type: 'nombre' },
      { wo: 'Fukk', fr: '10', type: 'nombre' }, { wo: 'Téeméer', fr: '100', type: 'nombre' }
    ],
    quiz: [
      { question: 'Que signifie "Juróom-benna"?', options: ['Quatre', 'Cinq', 'Six', 'Sept'], correct: 2 },
      { question: 'Comment dit-on "Deux"?', options: ['Benna', 'Ñaar', 'Ñeent', 'Juróom'], correct: 1 }
    ]
  },
  {
    id: 5, title: 'Expressions utiles', titleWo: 'Baat yi muññ', category: 'Quotidien', difficulty: 'Intermédiaire',
    phrases: [
      { wo: 'Jërëjëf', fr: 'Merci', context: 'Essentiel' },
      { wo: 'Waaw', fr: 'Oui', context: 'Affirmation' },
      { wo: 'Déet', fr: 'Non', context: 'Négation' },
      { wo: 'Dama dégg', fr: 'Je comprends', context: 'Confirmation' },
      { wo: 'Duma dégg', fr: 'Je ne comprends pas', context: 'Demande d\'aide' },
      { wo: 'Fii la nekk', fr: 'C\'est ici', context: 'Localisation' }
    ],
    vocabulary: [
      { wo: 'Jërëjëf', fr: 'Merci', type: 'politesse' }, { wo: 'Waaw', fr: 'Oui', type: 'affirmation' },
      { wo: 'Déet', fr: 'Non', type: 'négation' }, { wo: 'Dégg', fr: 'Comprendre', type: 'verbe' },
      { wo: 'Nekk', fr: 'Être/Etre situé', type: 'verbe' }, { wo: 'Fii', fr: 'Ici', type: 'adverbe' }
    ],
    quiz: [
      { question: 'Comment dit-on "Merci"?', options: ['Waaw', 'Jërëjëf', 'Déet', 'Dama dégg'], correct: 1 },
      { question: 'Que signifie "Duma dégg"?', options: ['Je comprends', 'Je ne comprends pas', 'Je sais', 'Je ne sais pas'], correct: 1 }
    ]
  },
  {
    id: 6, title: 'Temps et météo', titleWo: 'Tangi ak muus', category: 'Quotidien', difficulty: 'Intermédiaire',
    phrases: [
      { wo: 'Suba', fr: 'Demain', context: 'Temps' },
      { wo: 'Tay', fr: 'Aujourd\'hui', context: 'Temps' },
      { wo: 'Démb', fr: 'Hier', context: 'Temps' },
      { wo: 'Bés mi tang na', fr: 'Il fait chaud', context: 'Météo' },
      { wo: 'Naw dafa tuuti', fr: 'Le vent souffle', context: 'Météo' },
      { wo: 'Tangi', fr: 'Chaleur', context: 'Nom' }
    ],
    vocabulary: [
      { wo: 'Suba', fr: 'Demain', type: 'temps' }, { wo: 'Tay', fr: 'Aujourd\'hui', type: 'temps' },
      { wo: 'Démb', fr: 'Hier', type: 'temps' }, { wo: 'Tangi', fr: 'Chaleur', type: 'nom' },
      { wo: 'Naw', fr: 'Vent', type: 'nom' }, { wo: 'Tang', fr: 'Chaud', type: 'adjectif' }
    ],
    quiz: [
      { question: 'Comment dit-on "Demain"?', options: ['Tay', 'Démb', 'Suba', 'Fii'], correct: 2 },
      { question: 'Que signifie "Bés mi tang na"?', options: ['Il fait froid', 'Il pleut', 'Il fait chaud', 'Il fait beau'], correct: 2 }
    ]
  },
  {
    id: 7, title: 'Commerce', titleWo: 'Jaay-jëfandik', category: 'Professionnel', difficulty: 'Avancé',
    phrases: [
      { wo: 'Lu mooy toppat?', fr: 'Combien ça coûte?', context: 'Marchandage' },
      { wo: 'Dafa gis', fr: 'C\'est cher', context: 'Négociation' },
      { wo: 'Wonal ma', fr: 'Fais-moi un prix', context: 'Demande' },
      { wo: 'Dama bëgg jënd loolu', fr: 'Je veux acheter cela', context: 'Transaction' },
      { wo: 'Yobal ma ko', fr: 'Livre-moi ça', context: 'Commande' },
      { wo: 'Ndax am nga wàcc?', fr: 'Avez-vous du pain?', context: 'Demande' }
    ],
    vocabulary: [
      { wo: 'Jaay', fr: 'Vendre', type: 'verbe' }, { wo: 'Jënd', fr: 'Acheter', type: 'verbe' },
      { wo: 'Toppat', fr: 'Prix', type: 'nom' }, { wo: 'Wonal', fr: 'Réduction', type: 'nom' },
      { wo: 'Gis', fr: 'Cher', type: 'adjectif' }, { wo: 'Wàcc', fr: 'Pain', type: 'nom' }
    ],
    quiz: [
      { question: 'Comment demande-t-on le prix?', options: ['Dama bëgg jënd', 'Lu mooy toppat?', 'Wonal ma', 'Dafa gis'], correct: 1 },
      { question: 'Que signifie "Jënd"?', options: ['Vendre', 'Acheter', 'Marchander', 'Offrir'], correct: 1 }
    ]
  },
  {
    id: 8, title: 'Voyages', titleWo: 'Dëkk-dëkk', category: 'Quotidien', difficulty: 'Intermédiaire',
    phrases: [
      { wo: 'Fan la dëkk?', fr: 'Où habites-tu?', context: 'Géographie' },
      { wo: 'Ci Dakar la dëkk', fr: 'J\'habite à Dakar', context: 'Réponse' },
      { wo: 'Dama bëgg dem', fr: 'Je veux partir', context: 'Intention' },
      { wo: 'Lu tangaan?', fr: 'Par quoi commence-t-on?', context: 'Demande' },
      { wo: 'Noppal ma', fr: 'Excuse-moi/Excusez-moi', context: 'Politesse' },
      { wo: 'Fii ci Senegaal', fr: 'Ici au Sénégal', context: 'Localisation' }
    ],
    vocabulary: [
      { wo: 'Dëkk', fr: 'Ville/Habiter', type: 'nom/verbe' }, { wo: 'Dem', fr: 'Aller/Partir', type: 'verbe' },
      { wo: 'Fan', fr: 'Où', type: 'interrogatif' }, { wo: 'Noppal', fr: 'Excuser', type: 'verbe' },
      { wo: 'Dëkk-dëkk', fr: 'Voyage', type: 'nom' }, { wo: 'Ci', fr: 'À/En/Sur', type: 'préposition' }
    ],
    quiz: [
      { question: 'Comment dit-on "Où habites-tu?"?', options: ['Fan la dëkk?', 'Ci Dakar la dëkk', 'Dama bëgg dem', 'Fii ci Senegaal'], correct: 0 },
      { question: 'Que signifie "Dem"?', options: ['Venir', 'Aller/Partir', 'Rester', 'Habiter'], correct: 1 }
    ]
  }
];

const progressLevels = [
  { level: 1, name: 'Yàggal (Débutant)', xp: 0, max: 100, icon: '🌱' },
  { level: 2, name: 'Xel (Apprenti)', xp: 100, max: 300, icon: '🌿' },
  { level: 3, name: 'Xam (Intermédiaire)', xp: 300, max: 600, icon: '🌳' },
  { level: 4, name: 'Kàttan (Avancé)', xp: 600, max: 1000, icon: '🏆' },
  { level: 5, name: 'Baax (Expert)', xp: 1000, max: 1500, icon: '👑' },
  { level: 6, name: 'Màggal (Maître)', xp: 1500, max: 99999, icon: '🌟' }
];

function AudioPlayer({ text }: { text: string }) {
  const [playing, setPlaying] = useState(false);
  const speak = () => {
    if (!playing && 'speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'wo-SN';
      utterance.rate = 0.8;
      utterance.onend = () => setPlaying(false);
      window.speechSynthesis.speak(utterance);
      setPlaying(true);
    }
  };
  return (
    <button onClick={speak} className="p-2 rounded-full bg-[#4D6BFF]/20 hover:bg-[#4D6BFF]/40 transition-colors">
      {playing ? <Pause className="w-4 h-4 text-[#4D6BFF]" /> : <Volume2 className="w-4 h-4 text-[#4D6BFF]" />}
    </button>
  );
}

export default function Nand() {
  const [activeTab, setActiveTab] = useState<'lessons' | 'vocab' | 'quiz' | 'progress'>('lessons');
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null);
  const [quizAnswers, setQuizAnswers] = useState<Record<number, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [userXP, setUserXP] = useState(150);
  const [completedLessons, setCompletedLessons] = useState<number[]>([1]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('Tous');

  const categories = ['Tous', 'Basique', 'Quotidien', 'Professionnel'];
  const filteredLessons = lessons.filter(l => {
    const matchCat = activeCategory === 'Tous' || l.category === activeCategory;
    const matchSearch = !searchQuery || l.title.toLowerCase().includes(searchQuery.toLowerCase()) || l.titleWo.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCat && matchSearch;
  });

  const currentLevel = progressLevels.find(l => userXP >= l.xp && userXP < l.max) || progressLevels[progressLevels.length - 1];
  const nextLevel = progressLevels.find(l => l.xp > userXP) || currentLevel;
  const xpProgress = nextLevel ? ((userXP - currentLevel.xp) / (nextLevel.xp - currentLevel.xp)) * 100 : 100;

  const handleQuizAnswer = (qIdx: number, optionIdx: number) => {
    if (quizSubmitted) return;
    setQuizAnswers(prev => ({ ...prev, [qIdx]: optionIdx }));
  };

  const submitQuiz = () => {
    setQuizSubmitted(true);
    if (!selectedLesson) return;
    const correct = selectedLesson.quiz.filter((q, i) => quizAnswers[i] === q.correct).length;
    const earned = correct * 25;
    setUserXP(prev => prev + earned);
    if (correct >= selectedLesson.quiz.length / 2 && !completedLessons.includes(selectedLesson.id)) {
      setCompletedLessons(prev => [...prev, selectedLesson.id]);
    }
  };

  const resetQuiz = () => { setQuizAnswers({}); setQuizSubmitted(false); };

  useEffect(() => { window.scrollTo(0, 0); }, []);

  return (
    <div className="min-h-screen bg-[#050A14] text-white">
      <Navbar />

      {/* Hero */}
      <section className="relative pt-32 pb-20 px-6 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#0F8B8D]/10 to-transparent" />
        <div className="max-w-6xl mx-auto relative z-10">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#0F8B8D]/20 border border-[#0F8B8D]/30 mb-6">
              <Languages className="w-4 h-4 text-[#0F8B8D]" />
              <span className="text-xs font-medium text-[#0F8B8D] tracking-wider uppercase">nand.senegal-telecom.com</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold mb-4 bg-gradient-to-r from-[#0F8B8D] via-[#00E5A0] to-[#D4AF37] bg-clip-text text-transparent">NAND</h1>
            <p className="text-2xl md:text-3xl text-white/70 font-light mb-2 italic font-serif">Jàng Wolof — Apprenez le Wolof</p>
            <p className="text-lg text-white/50 max-w-2xl mx-auto">La plateforme digitale de référence pour apprendre le Wolof. 20 leçons interactives, audio natif, tests et certifications.</p>

            <div className="flex flex-wrap justify-center gap-6 mt-10">
              <div className="flex items-center gap-3 glass px-5 py-3 rounded-xl">
                <GraduationCap className="w-5 h-5 text-[#0F8B8D]" />
                <div className="text-left"><div className="text-lg font-bold">{lessons.length}</div><div className="text-xs text-white/50">Leçons</div></div>
              </div>
              <div className="flex items-center gap-3 glass px-5 py-3 rounded-xl">
                <Headphones className="w-5 h-5 text-[#00E5A0]" />
                <div className="text-left"><div className="text-lg font-bold">200+</div><div className="text-xs text-white/50">Phrases audio</div></div>
              </div>
              <div className="flex items-center gap-3 glass px-5 py-3 rounded-xl">
                <Trophy className="w-5 h-5 text-[#D4AF37]" />
                <div className="text-left"><div className="text-lg font-bold">{completedLessons.length}/{lessons.length}</div><div className="text-xs text-white/50">Complétées</div></div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Tabs */}
      <div className="sticky top-20 z-40 bg-[#050A14]/90 backdrop-blur-md border-b border-white/10">
        <div className="max-w-6xl mx-auto px-6 flex gap-1">
          {[
            { id: 'lessons' as const, label: 'Leçons', icon: BookOpen },
            { id: 'vocab' as const, label: 'Vocabulaire', icon: Languages },
            { id: 'quiz' as const, label: 'Tests', icon: CheckCircle },
            { id: 'progress' as const, label: 'Progression', icon: Trophy }
          ].map(tab => (
            <button key={tab.id} onClick={() => { setActiveTab(tab.id); setSelectedLesson(null); }}
              className={`flex items-center gap-2 px-5 py-3 text-sm font-medium transition-all ${activeTab === tab.id ? 'text-[#0F8B8D] border-b-2 border-[#0F8B8D]' : 'text-white/50 hover:text-white/80'}`}>
              <tab.icon className="w-4 h-4" /> {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-6 py-12 pb-32">
        {activeTab === 'lessons' && !selectedLesson && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            {/* Search & Filter */}
            <div className="flex flex-col md:flex-row gap-4 mb-8">
              <div className="relative flex-1">
                <input type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Rechercher une leçon..." className="w-full px-5 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-[#0F8B8D] outline-none text-sm" />
              </div>
              <div className="flex gap-2">
                {categories.map(c => (
                  <button key={c} onClick={() => setActiveCategory(c)} className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${activeCategory === c ? 'bg-[#0F8B8D] text-white' : 'bg-white/5 text-white/60 hover:bg-white/10'}`}>{c}</button>
                ))}
              </div>
            </div>

            {/* Lessons Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredLessons.map((lesson, idx) => (
                <motion.div key={lesson.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.1 }}
                  onClick={() => { setSelectedLesson(lesson); setActiveTab('lessons'); }}
                  className="glass-card p-6 rounded-2xl cursor-pointer hover:border-[#0F8B8D]/40 transition-all group">
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 rounded-xl bg-[#0F8B8D]/20 flex items-center justify-center">
                      <Music className="w-5 h-5 text-[#0F8B8D]" />
                    </div>
                    {completedLessons.includes(lesson.id) && (
                      <div className="w-6 h-6 rounded-full bg-[#00E5A0]/20 flex items-center justify-center">
                        <CheckCircle className="w-4 h-4 text-[#00E5A0]" />
                      </div>
                    )}
                  </div>
                  <h3 className="text-lg font-bold mb-1 group-hover:text-[#0F8B8D] transition-colors">{lesson.title}</h3>
                  <p className="text-sm text-[#0F8B8D] mb-2">{lesson.titleWo}</p>
                  <div className="flex items-center gap-3 text-xs text-white/40 mt-3">
                    <span>{lesson.category}</span>
                    <span className="w-1 h-1 rounded-full bg-white/20" />
                    <span>{lesson.difficulty}</span>
                    <span className="w-1 h-1 rounded-full bg-white/20" />
                    <span>{lesson.phrases.length} phrases</span>
                  </div>
                  <div className="mt-4 flex items-center gap-1 text-xs text-white/50">
                    <ChevronRight className="w-3 h-3" />
                    <span>Cliquez pour apprendre</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'lessons' && selectedLesson && (
          <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }}>
            <button onClick={() => setSelectedLesson(null)} className="flex items-center gap-2 text-white/60 hover:text-white mb-6 transition-colors">
              <ArrowRight className="w-4 h-4 rotate-180" /> Retour aux leçons
            </button>
            <div className="glass-card rounded-2xl p-8 mb-8">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h2 className="text-3xl font-bold mb-2">{selectedLesson.title}</h2>
                  <p className="text-xl text-[#0F8B8D] font-serif italic">{selectedLesson.titleWo}</p>
                </div>
                <button onClick={() => { setActiveTab('quiz'); resetQuiz(); }} className="px-4 py-2 rounded-lg bg-[#D4AF37]/20 text-[#D4AF37] text-sm font-medium hover:bg-[#D4AF37]/30 transition-colors">
                  Passer le test
                </button>
              </div>

              {/* Phrases */}
              <div className="mb-8">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-[#0F8B8D]" /> Phrases essentielles
                </h3>
                <div className="space-y-3">
                  {selectedLesson.phrases.map((phrase, i) => (
                    <div key={i} className="flex items-center gap-4 p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors">
                      <AudioPlayer text={phrase.wo} />
                      <div className="flex-1">
                        <p className="text-lg font-medium text-white">{phrase.wo}</p>
                        <p className="text-sm text-white/50">{phrase.fr}</p>
                        {phrase.context && <p className="text-xs text-[#0F8B8D] mt-1">{phrase.context}</p>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Vocabulary */}
              <div>
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Languages className="w-5 h-5 text-[#D4AF37]" /> Vocabulaire
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {selectedLesson.vocabulary.map((v, i) => (
                    <div key={i} className="p-4 rounded-xl bg-white/5 hover:bg-white/10 transition-colors flex items-center gap-3">
                      <AudioPlayer text={v.wo} />
                      <div>
                        <p className="font-medium">{v.wo}</p>
                        <p className="text-xs text-white/50">{v.fr}</p>
                        <span className="text-xs text-[#0F8B8D]">{v.type}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'vocab' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <h2 className="text-2xl font-bold mb-6">Dictionnaire Wolof-Français</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {lessons.flatMap(l => l.vocabulary.map((v, i) => ({ ...v, lesson: l.title, id: `${l.id}-${i}` }))).map((v) => (
                <div key={v.id} className="glass-card p-4 rounded-xl flex items-center gap-3 hover:border-[#0F8B8D]/30 transition-colors">
                  <AudioPlayer text={v.wo} />
                  <div className="flex-1">
                    <p className="font-medium">{v.wo}</p>
                    <p className="text-sm text-white/50">{v.fr}</p>
                  </div>
                  <span className="text-xs px-2 py-1 rounded bg-white/5 text-white/40">{v.type}</span>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'quiz' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            {!selectedLesson ? (
              <div>
                <h2 className="text-2xl font-bold mb-6">Choisissez une leçon à tester</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {lessons.map(l => (
                    <button key={l.id} onClick={() => { setSelectedLesson(l); resetQuiz(); }}
                      className="glass-card p-6 rounded-xl text-left hover:border-[#D4AF37]/40 transition-all">
                      <h3 className="font-bold mb-1">{l.title}</h3>
                      <p className="text-sm text-white/50">{l.quiz.length} questions</p>
                      {completedLessons.includes(l.id) && <span className="text-xs text-[#00E5A0] mt-2 inline-block">Déjà complété</span>}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div>
                <button onClick={() => setSelectedLesson(null)} className="flex items-center gap-2 text-white/60 hover:text-white mb-6">
                  <ArrowRight className="w-4 h-4 rotate-180" /> Changer de leçon
                </button>
                <h2 className="text-2xl font-bold mb-2">Test: {selectedLesson.title}</h2>
                <div className="space-y-6 mt-6">
                  {selectedLesson.quiz.map((q, qi) => (
                    <div key={qi} className="glass-card p-6 rounded-xl">
                      <p className="font-medium mb-4">{qi + 1}. {q.question}</p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {q.options.map((opt, oi) => {
                          const isSelected = quizAnswers[qi] === oi;
                          const isCorrect = q.correct === oi;
                          const showResult = quizSubmitted;
                          let btnClass = 'p-3 rounded-lg border text-left transition-all ';
                          if (showResult) {
                            if (isCorrect) btnClass += 'border-[#00E5A0] bg-[#00E5A0]/20 text-[#00E5A0]';
                            else if (isSelected) btnClass += 'border-red-400 bg-red-400/20 text-red-300';
                            else btnClass += 'border-white/10 bg-white/5 text-white/40';
                          } else {
                            btnClass += isSelected ? 'border-[#4D6BFF] bg-[#4D6BFF]/20' : 'border-white/10 bg-white/5 hover:bg-white/10';
                          }
                          return (
                            <button key={oi} onClick={() => handleQuizAnswer(qi, oi)} className={btnClass} disabled={quizSubmitted}>
                              <div className="flex items-center gap-3">
                                {showResult && isCorrect && <CheckCircle className="w-4 h-4" />}
                                {showResult && isSelected && !isCorrect && <XCircle className="w-4 h-4" />}
                                <span>{opt}</span>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
                {!quizSubmitted ? (
                  <button onClick={submitQuiz} disabled={Object.keys(quizAnswers).length < selectedLesson.quiz.length}
                    className="mt-6 px-8 py-3 rounded-xl bg-[#4D6BFF] text-white font-medium hover:bg-[#4D6BFF]/80 transition-colors disabled:opacity-40">
                    Soumettre le test
                  </button>
                ) : (
                  <div className="mt-6 flex items-center gap-4">
                    <div className="glass-card px-6 py-4 rounded-xl">
                      <p className="text-sm text-white/50">Score</p>
                      <p className="text-2xl font-bold text-[#00E5A0]">
                        {selectedLesson.quiz.filter((q, i) => quizAnswers[i] === q.correct).length}/{selectedLesson.quiz.length}
                      </p>
                    </div>
                    <button onClick={resetQuiz} className="px-6 py-3 rounded-xl bg-white/10 hover:bg-white/20 transition-colors flex items-center gap-2">
                      <RotateCcw className="w-4 h-4" /> Recommencer
                    </button>
                  </div>
                )}
              </div>
            )}
          </motion.div>
        )}

        {activeTab === 'progress' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <h2 className="text-2xl font-bold mb-6">Votre Progression</h2>
            <div className="glass-card p-8 rounded-2xl mb-8">
              <div className="flex items-center gap-6 mb-6">
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#0F8B8D] to-[#00E5A0] flex items-center justify-center text-3xl">
                  {currentLevel.icon}
                </div>
                <div>
                  <p className="text-sm text-white/50">Niveau actuel</p>
                  <h3 className="text-2xl font-bold">{currentLevel.name}</h3>
                  <p className="text-sm text-white/50">{userXP} XP</p>
                </div>
              </div>
              <div className="w-full h-3 bg-white/10 rounded-full overflow-hidden mb-2">
                <div className="h-full bg-gradient-to-r from-[#0F8B8D] to-[#00E5A0] rounded-full transition-all duration-1000" style={{ width: `${xpProgress}%` }} />
              </div>
              <p className="text-xs text-white/40 text-right">{userXP} / {nextLevel.xp} XP pour le niveau suivant</p>
            </div>

            <h3 className="text-lg font-semibold mb-4">Leçons complétées</h3>
            <div className="space-y-3">
              {lessons.map(l => {
                const done = completedLessons.includes(l.id);
                return (
                  <div key={l.id} className={`flex items-center gap-4 p-4 rounded-xl border ${done ? 'border-[#00E5A0]/30 bg-[#00E5A0]/10' : 'border-white/5 bg-white/5'}`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${done ? 'bg-[#00E5A0]/20' : 'bg-white/10'}`}>
                      {done ? <CheckCircle className="w-4 h-4 text-[#00E5A0]" /> : <div className="w-3 h-3 rounded-full bg-white/20" />}
                    </div>
                    <div className="flex-1">
                      <p className={`font-medium ${done ? 'text-[#00E5A0]' : 'text-white/50'}`}>{l.title}</p>
                      <p className="text-xs text-white/30">{l.titleWo}</p>
                    </div>
                    {done && <Star className="w-4 h-4 text-[#D4AF37]" />}
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}
      </div>

      {/* Footer */}
      <footer className="border-t border-white/10 py-12 px-6">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-sm text-white/30">NAND — Plateforme d'apprentissage du Wolof par SENEGAL TELECOM</p>
          <p className="text-xs text-white/20 mt-2">Préservation et valorisation du patrimoine linguistique sénégalais</p>
        </div>
      </footer>
    </div>
  );
}
