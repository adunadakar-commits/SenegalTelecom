import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Navbar from '../components/Navbar';
import { Send, Sparkles, Image, Code, Languages, Bot, User, Wand2, Copy, Loader } from 'lucide-react';

interface Message {
  id: number;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

const quickPrompts = [
  'Ecris un poeme sur le Senegal',
  'Explique la fibre optique simplement',
  'Genere une idee de startup africaine',
  'Traduis en wolof: Bonjour comment vas-tu',
  'Code une calculatrice en Python',
  'Resume l\'histoire du Mali',
];

const features = [
  { icon: Sparkles, title: 'SENAI Chat', desc: 'Assistant IA conversationnel intelligent', color: '#7B2D8E' },
  { icon: Image, title: 'Generateur d\'images', desc: 'Creez des visuels avec l\'IA generative', color: '#FF006E' },
  { icon: Code, title: 'Assistant Code', desc: 'Aide au developpement dans 20+ langages', color: '#00D4AA' },
  { icon: Languages, title: 'Traduction', desc: '50+ langues africaines et mondiales', color: '#4D6BFF' },
];

const sampleImages = [
  { prompt: 'Un lion majestueux devant la mosquee de Touba', status: 'done' as const },
  { prompt: 'Ville futuriste de Dakar en 2050', status: 'done' as const },
  { prompt: 'Femme africaine avec des motifs traditionnels', status: 'done' as const },
];

export default function IA() {
  const [messages, setMessages] = useState<Message[]>([
    { id: 1, text: 'As-salamu alaykum! Je suis **SENAI**, votre assistant IA de Senegal Telecom. Je peux repondre a vos questions, generer des images, traduire dans 50+ langues ou vous aider a coder. Comment puis-je vous aider?', sender: 'bot', timestamp: new Date() },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [activeTab, setActiveTab] = useState('chat');
  const [generating, setGenerating] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const handleSend = (text: string) => {
    if (!text.trim()) return;
    const userMsg: Message = { id: Date.now(), text, sender: 'user', timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      const responses = [
        'Excellente question ! Le Senegal Telecom dispose d\'un reseau fibre optique de plus de 8 000 km, couvrant les principales villes du Senegal et connectant l\'Afrique de l\'Ouest au monde entier via 4 cables sous-marins.',
        'Je peux vous aider avec ca ! Notre equipe technique est disponible 24/7. Vous pouvez les contacter au 800 100 100 ou via l\'espace client en ligne.',
        'Tres interessant ! Le Senegal est un leader dans les telecommunications en Afrique de l\'Ouest avec un taux de penetration mobile de plus de 90%. Notre reseau 4G couvre 98% de la population.',
        'Avec plaisir ! Senegal Telecom connecte 5 pays en Afrique de l\'Ouest : Senegal, Mali, Guinee, Guinee-Bissau et Sierra Leone. Notre mission est de connecter l\'Afrique au monde.',
        'Voici une information utile : notre service Aduna Money compte plus de 8 millions d\'utilisateurs actifs et permet des transferts d\'argent, paiements de factures, achats en ligne et bien plus.',
      ];
      const botMsg: Message = { id: Date.now() + 1, text: responses[Math.floor(Math.random() * responses.length)], sender: 'bot', timestamp: new Date() };
      setMessages(prev => [...prev, botMsg]);
      setIsTyping(false);
    }, 1200 + Math.random() * 800);
  };

  const handleGenerate = () => {
    setGenerating(true);
    setTimeout(() => setGenerating(false), 3000);
  };

  return (
    <div className="min-h-screen bg-[#0a0a18] text-[#E0E6F1]">
      <Navbar />
      <section className="relative pt-32 pb-16 overflow-hidden">
        <div className="absolute inset-0"><img src="/p4-neural.jpg" alt="" className="w-full h-full object-cover opacity-25" /><div className="absolute inset-0 bg-gradient-to-b from-[#0a0a18] via-[#0a0a18]/80 to-[#0a0a18]" /></div>
        <div className="relative z-10 max-w-[1440px] mx-auto px-6 lg:px-12">
          <motion.div className="text-center space-y-5" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#7B2D8E]/30 glass"><Sparkles className="w-4 h-4 text-[#00D4AA]" /><span className="text-sm font-medium text-[#00D4AA] tracking-wider">Powered by AI — SENAI Engine</span></div>
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold font-['Space_Grotesk']">SENEGAL TELECOM <span className="text-gradient-ia">IA</span></h1>
            <p className="text-lg text-[#8B95A8] max-w-2xl mx-auto">L'intelligence artificielle au service de l'Afrique. Chatbot conversationnel, generation d'images, assistant de programmation et traduction multilingue.</p>
          </motion.div>
        </div>
      </section>

      <section className="py-8">
        <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
          <div className="flex flex-wrap justify-center gap-3 mb-12">
            {[{ k: 'chat', l: 'SENAI Chat', i: Sparkles }, { k: 'image', l: 'Generateur d\'Images', i: Image }, { k: 'code', l: 'Assistant Code', i: Code }].map(t => (
              <button key={t.k} onClick={() => setActiveTab(t.k)} className={`flex items-center gap-2 px-6 py-3 rounded-xl border transition-all ${activeTab === t.k ? 'border-[#FF006E]/50 bg-[#FF006E]/10' : 'border-white/8 glass hover:border-white/15'}`}><t.i className="w-5 h-5 text-[#FF006E]" /><span className="text-sm font-medium">{t.l}</span></button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            {/* CHAT */}
            {activeTab === 'chat' && (
              <motion.div key="chat" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="max-w-4xl mx-auto">
                <div className="rounded-2xl border border-[#7B2D8E]/20 glass-strong overflow-hidden">
                  <div className="p-4 border-b border-[#7B2D8E]/15 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-[#7B2D8E]/20 flex items-center justify-center"><Bot className="w-6 h-6 text-[#FF006E]" /></div>
                    <div><div className="text-sm font-semibold text-[#E0E6F1]">SENAI</div><div className="text-xs text-[#00D4AA] flex items-center gap-1.5"><div className="w-1.5 h-1.5 rounded-full bg-[#00D4AA] animate-pulse" />En ligne</div></div>
                    <div className="ml-auto flex items-center gap-2"><span className="px-2 py-0.5 rounded-full text-[10px] glass text-[#8B95A8]">GPT-4</span></div>
                  </div>
                  <div className="h-[28rem] overflow-y-auto p-4 space-y-4">
                    {messages.map(msg => (
                      <div key={msg.id} className={`flex gap-3 ${msg.sender === 'user' ? 'flex-row-reverse' : ''}`}>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${msg.sender === 'bot' ? 'bg-[#7B2D8E]/20' : 'bg-[#00D4AA]/15'}`}>
                          {msg.sender === 'bot' ? <Bot className="w-4 h-4 text-[#FF006E]" /> : <User className="w-4 h-4 text-[#00D4AA]" />}
                        </div>
                        <div className={`max-w-[75%] p-3.5 rounded-xl text-sm leading-relaxed ${msg.sender === 'bot' ? 'bg-[#7B2D8E]/8 border border-[#7B2D8E]/15 text-[#E0E6F1]' : 'bg-[#00D4AA]/8 border border-[#00D4AA]/15 text-[#E0E6F1]'}`}>
                          {msg.text}
                        </div>
                      </div>
                    ))}
                    {isTyping && (
                      <div className="flex gap-3">
                        <div className="w-8 h-8 rounded-full bg-[#7B2D8E]/20 flex items-center justify-center"><Bot className="w-4 h-4 text-[#FF006E]" /></div>
                        <div className="p-3.5 rounded-xl bg-[#7B2D8E]/8 border border-[#7B2D8E]/15">
                          <div className="flex gap-1.5"><div className="w-2 h-2 rounded-full bg-[#FF006E] animate-bounce" /><div className="w-2 h-2 rounded-full bg-[#FF006E] animate-bounce" style={{ animationDelay: '0.1s' }} /><div className="w-2 h-2 rounded-full bg-[#FF006E] animate-bounce" style={{ animationDelay: '0.2s' }} /></div>
                        </div>
                      </div>
                    )}
                    <div ref={chatEndRef} />
                  </div>
                  <div className="px-4 pb-2 flex flex-wrap gap-2">
                    {quickPrompts.map(p => <button key={p} onClick={() => handleSend(p)} className="px-3 py-1.5 rounded-full border border-[#7B2D8E]/15 text-xs text-[#8B95A8] hover:border-[#FF006E]/30 hover:text-[#E0E6F1] transition-colors">{p}</button>)}
                  </div>
                  <div className="p-4 border-t border-[#7B2D8E]/15">
                    <div className="flex gap-3">
                      <input type="text" value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSend(input)} placeholder="Posez votre question a SENAI..." className="flex-1 px-4 py-3 rounded-xl bg-[#0a0a18] border border-[#7B2D8E]/20 text-[#E0E6F1] placeholder-[#8B95A8] text-sm focus:outline-none focus:border-[#FF006E] transition-colors" />
                      <button onClick={() => handleSend(input)} className="px-5 py-3 rounded-xl bg-[#FF006E] text-white hover:bg-[#e0005e] transition-colors"><Send className="w-5 h-5" /></button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* IMAGE GENERATOR */}
            {activeTab === 'image' && (
              <motion.div key="image" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="max-w-4xl mx-auto">
                <div className="rounded-2xl border border-[#FF006E]/20 glass-strong p-8 text-center space-y-6">
                  <Wand2 className="w-16 h-16 text-[#FF006E] mx-auto" />
                  <h3 className="text-2xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">Generateur d\'Images IA</h3>
                  <p className="text-[#8B95A8]">Decrivez l\'image que vous souhaitez creer et notre IA la generera instantanement.</p>
                  <div className="flex gap-3 max-w-lg mx-auto">
                    <input type="text" placeholder="Un lion majestueux devant la mosquee de Touba..." className="flex-1 px-4 py-3 rounded-xl bg-[#0a0a18] border border-[#FF006E]/20 text-[#E0E6F1] placeholder-[#8B95A8] text-sm focus:outline-none focus:border-[#FF006E]" />
                    <button onClick={handleGenerate} disabled={generating} className="px-6 py-3 rounded-xl bg-[#FF006E] text-white font-semibold hover:bg-[#e0005e] transition-all flex items-center gap-2 disabled:opacity-50">
                      {generating ? <><Loader className="w-4 h-4 animate-spin" /> Generation...</> : <><Sparkles className="w-4 h-4" /> Generer</>}
                    </button>
                  </div>
                  <div className="grid grid-cols-3 gap-4 mt-8">
                    {sampleImages.map((img, i) => (
                      <div key={i} className="group relative aspect-square rounded-xl border border-[#7B2D8E]/15 bg-[#0a0a18] overflow-hidden">
                        {generating && i === 0 ? <div className="absolute inset-0 flex items-center justify-center"><Loader className="w-8 h-8 text-[#FF006E] animate-spin" /></div> : <div className="absolute inset-0 shimmer flex items-center justify-center"><Sparkles className="w-8 h-8 text-[#7B2D8E]/40" /></div>}
                        <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/80 to-transparent"><p className="text-[10px] text-[#8B95A8] truncate">{img.prompt}</p></div>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {/* CODE ASSISTANT */}
            {activeTab === 'code' && (
              <motion.div key="code" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="max-w-4xl mx-auto">
                <div className="rounded-2xl border border-[#00D4AA]/20 glass-strong overflow-hidden">
                  <div className="p-4 border-b border-[#00D4AA]/15 flex items-center gap-3">
                    <Code className="w-5 h-5 text-[#00D4AA]" /><span className="text-sm font-semibold">Assistant Code</span>
                    <span className="ml-auto px-2 py-0.5 rounded-full text-[10px] glass text-[#8B95A8]">Python, JS, Java, C++, SQL...</span>
                  </div>
                  <div className="p-6 space-y-4">
                    <p className="text-sm text-[#8B95A8]">Demandez de l'aide pour ecrire, debugger ou expliquer du code dans n'importe quel langage de programmation.</p>
                    <div className="rounded-xl bg-[#0a0a18] border border-[#00D4AA]/15 p-4">
                      <div className="flex items-center justify-between mb-3"><span className="text-xs text-[#8B95A8]">Example: Hello World en Python</span><button className="flex items-center gap-1 text-xs text-[#8B95A8] hover:text-[#00D4AA] transition-colors"><Copy className="w-3 h-3" /> Copier</button></div>
                      <pre className="text-sm text-[#00D4AA] font-mono leading-relaxed"><code>{`def saluer(nom="Afrique"):
    print(f"As-salamu alaykum, {nom}!")
    return "Bienvenue chez Senegal Telecom"

saluer()`}</code></pre>
                    </div>
                    <div className="flex gap-3">
                      <input type="text" placeholder="Ecrivez une fonction qui calcule la factorielle..." className="flex-1 px-4 py-3 rounded-xl bg-[#0a0a18] border border-[#00D4AA]/20 text-[#E0E6F1] placeholder-[#8B95A8] text-sm focus:outline-none focus:border-[#00D4AA]" />
                      <button className="px-5 py-3 rounded-xl bg-[#00D4AA] text-[#0a0a18] font-semibold hover:bg-[#00b88d] transition-colors"><Send className="w-5 h-5" /></button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* FEATURES GRID */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5 mt-16">
            {features.map((f, i) => (
              <motion.div key={f.title} className="p-6 rounded-xl glass hover:border-white/15 transition-all group" initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}>
                <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4" style={{ backgroundColor: `${f.color}15` }}><f.icon className="w-6 h-6 group-hover:scale-110 transition-transform" style={{ color: f.color }} /></div>
                <h4 className="text-lg font-semibold text-[#E0E6F1] mb-1">{f.title}</h4>
                <p className="text-sm text-[#8B95A8]">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
