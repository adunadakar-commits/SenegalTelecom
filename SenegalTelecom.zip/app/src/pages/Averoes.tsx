import { useState } from 'react';
import { motion } from 'framer-motion';
import Navbar from '../components/Navbar';
import { BookOpen, GraduationCap, Users, Play, Quote, Library, Lightbulb, Globe, Scroll, PlayCircle, Star, Clock, ChevronRight } from 'lucide-react';

const courses = [
  { title: 'Philosophie Arabe: D\'Al-Kindi a Averroes', instructor: 'Dr. Moussa Diallo', students: 1240, duration: '12h', level: 'Debutant', image: '/p3-manuscript.jpg', rating: 4.9, lessons: 24 },
  { title: 'Logique, Rhetorique et Sciences', instructor: 'Prof. Amina Sow', students: 890, duration: '8h', level: 'Intermediaire', image: '/p3-averoes.jpg', rating: 4.8, lessons: 16 },
  { title: 'Sciences Islamiques: Fiqh et Tafsir', instructor: 'Cheikh Ibrahim Ndiaye', students: 2100, duration: '20h', level: 'Avance', image: '/p2-quran.jpg', rating: 5.0, lessons: 40 },
  { title: 'Mathematiques Arabes: L\'Age d\'Or', instructor: 'Dr. Khalil Faye', students: 650, duration: '10h', level: 'Intermediaire', image: '/p4-neural.jpg', rating: 4.7, lessons: 20 },
  { title: 'Medecine et Pharmacopee Islamique', instructor: 'Dr. Fatou Mbaye', students: 430, duration: '6h', level: 'Debutant', image: '/p1-fiber.jpg', rating: 4.6, lessons: 12 },
  { title: 'Histoire de la Pensee Africaine', instructor: 'Prof. Amadou Ba', students: 1800, duration: '15h', level: 'Tous niveaux', image: '/p1-hero.jpg', rating: 4.9, lessons: 30 },
];

const quotes = [
  { text: "L'ignorance mene a la peur, la peur mene a la haine, et la haine mene a la violence. Voila l'equation.", author: 'Averroes (Ibn Rushd)', era: 'Cordoue, 1126-1198' },
  { text: "Apprendre sans reflexion est une perte d'energie, reflectir sans apprendre est dangereux.", author: 'Confucius', era: 'Chine, -551--479' },
  { text: "La connaissance est la lumiere qui dissipe les tenebres de l'ignorance.", author: 'Al-Ghazali', era: 'Perse, 1058-1111' },
  { text: "Celui qui sait et sait qu'il sait est un sage, suivez-le.", author: 'Proverbe arabe', era: 'Antiquite' },
];

const books = [
  { title: 'Tahafut al-Tahafut', author: 'Averroes (Ibn Rushd)', year: '1190', category: 'Philosophie', desc: "Refutation des theologiens, defense de la philosophie contre l'attaque d'Al-Ghazali." },
  { title: 'Le Canon de la Medecine', author: 'Avicenne (Ibn Sina)', year: '1025', category: 'Medecine', desc: "L'ouvrage medical le plus important du Moyen Age, utilise pendant plus de 600 ans." },
  { title: 'Les Elements', author: 'Euclide', year: '-300', category: 'Mathematiques', desc: "Le fondement de la geometrie moderne, traduit et enrichi par les savants arabes." },
  { title: "Al-Kitab al-Mukhtasar", author: 'Al-Khwarizmi', year: '820', category: 'Mathematiques', desc: 'Introduction a l\'algebre et aux algorithmes qui ont revolutionne les mathematiques.' },
  { title: 'Les Voyages (Rihla)', author: 'Ibn Battuta', year: '1355', category: 'Geographie', desc: "Recit de voyage couvrant 117 000 km a travers l'Afrique, l'Asie et l'Europe." },
  { title: "Le Livre de l'Optique", author: 'Ibn Al-Haytham', year: '1011', category: 'Physique', desc: 'Pionnier de la theorie moderne de la vision et de la camera obscure.' },
];

export default function Averoes() {
  const [activeQuote, setActiveQuote] = useState(0);
  const [activeCourse, setActiveCourse] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-[#1a1209] text-[#F5F5DC]">
      <Navbar />
      {/* HERO */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0"><img src="/p3-manuscript.jpg" alt="" className="w-full h-full object-cover opacity-35" /><div className="absolute inset-0 bg-gradient-to-b from-[#1a1209] via-[#1a1209]/80 to-[#1a1209]" /></div>
        <div className="relative z-10 max-w-[1440px] mx-auto px-6 lg:px-12">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div className="space-y-6" initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8 }}>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#D4AF37]/30 glass"><GraduationCap className="w-4 h-4 text-[#D4AF37]" /><span className="text-sm font-medium text-[#D4AF37] tracking-wider">Plateforme Educative</span></div>
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold font-['Space_Grotesk'] leading-tight">AVEROES <span className="text-gradient-averoes">ACADEMY</span></h1>
              <p className="text-lg text-[#8B95A8] leading-relaxed max-w-lg">Parce que le savoir est eternel. Une plateforme dediee a la transmission des sciences, de la philosophie et du savoir africain et islamique depuis la Maison de la Sagesse jusqu'a nos jours.</p>
              <div className="flex gap-4">
                <a href="#courses" className="px-8 py-4 bg-[#D4AF37] text-[#1a1209] font-semibold tracking-wider uppercase rounded-xl hover:bg-[#c9a030] transition-colors flex items-center gap-2">Explorer les cours <ChevronRight className="w-5 h-5" /></a>
              </div>
            </motion.div>
            <motion.div className="hidden lg:block" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.8, delay: 0.2 }}>
              <div className="p-8 rounded-2xl glass" style={{ borderColor: 'rgba(212, 175, 55, 0.2)' }}>
                <img src="/p3-averoes.jpg" alt="Averroes" className="w-full h-48 object-cover rounded-xl mb-6" />
                <Quote className="w-8 h-8 text-[#D4AF37] mb-4" />
                <p className="text-xl italic text-[#E0E6F1] mb-4 leading-relaxed">"{quotes[activeQuote].text}"</p>
                <p className="text-sm text-[#D4AF37] font-semibold">— {quotes[activeQuote].author}</p>
                <p className="text-xs text-[#8B95A8]">{quotes[activeQuote].era}</p>
                <div className="flex gap-2 mt-6">
                  {quotes.map((_, i) => <button key={i} onClick={() => setActiveQuote(i)} className={`h-2 rounded-full transition-all ${activeQuote === i ? 'bg-[#D4AF37] w-8' : 'bg-[#D4AF37]/30 w-2'}`} />)}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* STATS */}
      <section className="py-12">
        <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
          <motion.div className="grid grid-cols-2 lg:grid-cols-4 gap-6" initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            {[{ icon: Users, value: '50,000+', label: 'Apprenants' }, { icon: BookOpen, value: '200+', label: 'Cours' }, { icon: Library, value: '10,000+', label: 'Livres numeriques' }, { icon: Globe, value: '25', label: 'Pays representes' }].map((s) => (
              <div key={s.label} className="p-6 rounded-xl glass text-center" style={{ borderColor: 'rgba(212, 175, 55, 0.1)' }}>
                <s.icon className="w-8 h-8 text-[#D4AF37] mx-auto mb-3" /><div className="text-2xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">{s.value}</div><div className="text-sm text-[#8B95A8]">{s.label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* COURSES */}
      <section id="courses" className="py-16">
        <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
          <motion.div className="flex items-center gap-3 mb-10" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <BookOpen className="w-7 h-7 text-[#D4AF37]" />
            <h2 className="text-3xl md:text-4xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">Cours <span className="text-[#D4AF37]">Populaires</span></h2>
          </motion.div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map((c, idx) => (
              <motion.div key={c.title} className="group rounded-2xl glass overflow-hidden cursor-pointer transition-all hover:border-[#D4AF37]/20" style={{ borderColor: 'rgba(255,255,255,0.05)' }} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: idx * 0.1 }} onClick={() => setActiveCourse(activeCourse === idx ? null : idx)}>
                <div className="relative h-48 overflow-hidden">
                  <img src={c.image} alt="" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1a1209] to-transparent" />
                  <div className="absolute top-4 right-4 px-3 py-1 rounded-full bg-[#D4AF37] text-[#1a1209] text-xs font-bold">{c.level}</div>
                  <div className="absolute bottom-4 left-4 flex items-center gap-1"><Star className="w-4 h-4 text-[#FFD23F] fill-[#FFD23F]" /><span className="text-sm text-[#E0E6F1] font-bold">{c.rating}</span></div>
                </div>
                <div className="p-6 space-y-3">
                  <h3 className="text-lg font-bold text-[#E0E6F1] font-['Space_Grotesk'] group-hover:text-[#D4AF37] transition-colors">{c.title}</h3>
                  <p className="text-sm text-[#8B95A8]">par {c.instructor}</p>
                  <div className="flex items-center gap-4 text-xs text-[#8B95A8]"><span className="flex items-center gap-1"><Users className="w-3 h-3" />{c.students.toLocaleString()}</span><span className="flex items-center gap-1"><Clock className="w-3 h-3" />{c.duration}</span><span className="flex items-center gap-1"><PlayCircle className="w-3 h-3" />{c.lessons} lecons</span></div>
                  <button className="w-full py-3 rounded-xl border border-[#D4AF37]/20 text-[#D4AF37] font-semibold hover:bg-[#D4AF37]/10 transition-colors flex items-center justify-center gap-2"><Play className="w-4 h-4" /> Commencer</button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* LIBRARY */}
      <section className="py-16 pb-24">
        <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
          <div className="grid lg:grid-cols-5 gap-8">
            <div className="lg:col-span-3">
              <motion.div className="flex items-center gap-3 mb-8" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
                <Library className="w-7 h-7 text-[#D4AF37]" />
                <h2 className="text-3xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">Bibliotheque <span className="text-[#D4AF37]">Numerique</span></h2>
              </motion.div>
              <div className="space-y-3">
                {books.map((b, i) => (
                  <motion.div key={b.title} className="flex items-start gap-4 p-4 rounded-xl glass hover:border-[#D4AF37]/15 transition-all" style={{ borderColor: 'rgba(255,255,255,0.05)' }} initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}>
                    <Scroll className="w-8 h-8 text-[#D4AF37] shrink-0 mt-1" />
                    <div className="flex-1">
                      <div className="text-sm font-semibold text-[#E0E6F1]">{b.title}</div>
                      <div className="text-xs text-[#8B95A8]">{b.author} — {b.year}</div>
                      <div className="text-xs text-[#8B95A8] mt-1">{b.desc}</div>
                    </div>
                    <span className="px-3 py-1 rounded-full text-xs border border-[#D4AF37]/20 text-[#D4AF37] shrink-0">{b.category}</span>
                  </motion.div>
                ))}
              </div>
            </div>
            <div className="lg:col-span-2 space-y-6">
              <motion.div className="p-8 rounded-2xl glass" style={{ borderColor: 'rgba(212, 175, 55, 0.2)' }} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
                <Lightbulb className="w-10 h-10 text-[#D4AF37] mb-4" />
                <h3 className="text-2xl font-bold text-[#E0E6F1] font-['Space_Grotesk'] mb-4">La Quete du Savoir</h3>
                <p className="text-[#8B95A8] leading-relaxed mb-6">Averroes Academy s'inspire de la Maison de la Sagesse (Bayt al-Hikma) de Baghdad, ou savants chretiens, musulmans et juifs ont forge ensemble les fondements de la civilisation moderne pendant l'Age d'Or islamique.</p>
                <img src="/p3-students.jpg" alt="Students" className="w-full h-40 object-cover rounded-xl mb-4" />
                <div className="grid grid-cols-3 gap-3 text-center">
                  {[{ label: 'Philosophie', icon: BookOpen }, { label: 'Sciences', icon: Lightbulb }, { label: 'Arts', icon: Scroll }].map(d => (
                    <div key={d.label} className="p-3 rounded-lg glass"><d.icon className="w-5 h-5 text-[#D4AF37] mx-auto mb-1" /><div className="text-[10px] text-[#8B95A8]">{d.label}</div></div>
                  ))}
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
