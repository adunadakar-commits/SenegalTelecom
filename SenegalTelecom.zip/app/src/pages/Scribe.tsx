/* Scribe.tsx - Nand Patrimoine: Transcription & Audio Annotation */
import { useState, useRef, useEffect } from 'react';
import Navbar from '../components/Navbar';
import { motion } from 'framer-motion';
import { Mic, Play, Pause, Save, Upload, FileText, Download, Share2, Volume2, Type, ChevronRight, Headphones, PenTool, BookOpen, Radio, RotateCcw, CheckCircle, AlertCircle, Layers, Globe, Lock, Zap, Music } from 'lucide-react';

interface TranscriptionSegment {
  id: string;
  start: number;
  end: number;
  text: string;
  speaker?: string;
  confidence: number;
  lang: string;
}

interface AudioProject {
  id: string;
  name: string;
  duration: number;
  segments: TranscriptionSegment[];
  status: 'uploaded' | 'processing' | 'transcribed' | 'reviewed';
  date: string;
  language: string;
}

const sampleProjects: AudioProject[] = [
  {
    id: '1', name: 'Conte traditionnel - Le lion et la hyène', duration: 342,
    status: 'transcribed', date: '2026-04-20', language: 'Wolof',
    segments: [
      { id: 's1', start: 0, end: 12, text: 'Ci bés bi, amoon na ay xaj ak buumu...', speaker: 'Narrateur', confidence: 0.94, lang: 'wo' },
      { id: 's2', start: 12, end: 28, text: 'Buuma bi dafa bëgg xaj yi ñu ko xalaat...', speaker: 'Narrateur', confidence: 0.91, lang: 'wo' },
      { id: 's3', start: 28, end: 45, text: 'Waaye xaj bi am na xel bu metti...', speaker: 'Narrateur', confidence: 0.88, lang: 'wo' },
    ]
  },
  {
    id: '2', name: 'Interview - Griot de Médina', duration: 1280,
    status: 'reviewed', date: '2026-04-18', language: 'Wolof',
    segments: [
      { id: 's1', start: 0, end: 15, text: 'Sama tur mooy Babacar Ndiaye, sama baay mooy këyit...', speaker: 'Babacar Ndiaye', confidence: 0.96, lang: 'wo' },
      { id: 's2', start: 15, end: 32, text: 'Dama bëgg wax ci wàllu njàng mu am solo ci sunu àdduna...', speaker: 'Babacar Ndiaye', confidence: 0.93, lang: 'wo' },
    ]
  },
  {
    id: '3', name: 'Poème - Yàlla bu mag bi', duration: 186,
    status: 'processing', date: '2026-04-22', language: 'Wolof',
    segments: []
  },
  {
    id: '4', name: 'Proverbes recueillis - Kaolack', duration: 560,
    status: 'uploaded', date: '2026-04-23', language: 'Wolof',
    segments: []
  }
];

const supportedLanguages = [
  { code: 'wo', name: 'Wolof', flag: '🇸🇳', model: 'Whisper-Wolof-v3' },
  { code: 'fr', name: 'Français', flag: '🇫🇷', model: 'Whisper-Large-v3' },
  { code: 'ar', name: 'Arabe', flag: '🇸🇦', model: 'Whisper-Arabic-v2' },
  { code: 'ff', name: 'Peul', flag: '🇸🇳', model: 'Whisper-Fula-v1' },
  { code: 'sn', name: 'Sérère', flag: '🇸🇳', model: 'Whisper-Serer-beta' },
  { code: 'dy', name: 'Diola', flag: '🇸🇳', model: 'Whisper-Jola-beta' },
  { code: 'mn', name: 'Mandinka', flag: '🇸🇳', model: 'Whisper-Mandinka-beta' },
  { code: 'bm', name: 'Bambara', flag: '🇲🇱', model: 'Whisper-Bambara-v1' },
];

const statusConfig = {
  uploaded: { color: '#4D6BFF', icon: Upload, label: 'Uploadé' },
  processing: { color: '#D4AF37', icon: Zap, label: 'Transcription en cours...' },
  transcribed: { color: '#00E5A0', icon: CheckCircle, label: 'Transcrit' },
  reviewed: { color: '#0F8B8D', icon: Lock, label: 'Validé' }
};

export default function Scribe() {
  const [projects, setProjects] = useState<AudioProject[]>(sampleProjects);
  const [activeProject, setActiveProject] = useState<AudioProject | null>(null);
  const [activeTab, setActiveTab] = useState<'projects' | 'transcribe' | 'editor' | 'corpus'>('projects');
  const [selectedLang, setSelectedLang] = useState('wo');
  const [isRecording, setIsRecording] = useState(false);
  const [recordTime, setRecordTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, _setCurrentTime] = useState(0);
  const [editingSegment, setEditingSegment] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const [newProjectName, setNewProjectName] = useState('');
  const recordInterval = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (isRecording) {
      recordInterval.current = setInterval(() => setRecordTime(p => p + 1), 1000);
    } else {
      if (recordInterval.current) clearInterval(recordInterval.current);
    }
    return () => { if (recordInterval.current) clearInterval(recordInterval.current); };
  }, [isRecording]);

  useEffect(() => { window.scrollTo(0, 0); }, []);

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  };

  const handleCreateProject = () => {
    if (!newProjectName.trim()) return;
    const newProject: AudioProject = {
      id: Date.now().toString(),
      name: newProjectName,
      duration: 0,
      segments: [],
      status: 'uploaded',
      date: new Date().toISOString().split('T')[0],
      language: selectedLang
    };
    setProjects(prev => [newProject, ...prev]);
    setNewProjectName('');
    setActiveProject(newProject);
    setActiveTab('editor');
  };

  const handleSaveSegment = (segId: string) => {
    if (!activeProject) return;
    setProjects(prev => prev.map(p => {
      if (p.id !== activeProject.id) return p;
      return {
        ...p,
        segments: p.segments.map(s => s.id === segId ? { ...s, text: editText } : s)
      };
    }));
    setActiveProject(prev => prev ? {
      ...prev,
      segments: prev.segments.map(s => s.id === segId ? { ...s, text: editText } : s)
    } : null);
    setEditingSegment(null);
    setEditText('');
  };

  const confidenceColor = (c: number) => c >= 0.9 ? 'text-[#00E5A0]' : c >= 0.7 ? 'text-[#D4AF37]' : 'text-red-400';

  return (
    <div className="min-h-screen bg-[#050A14] text-white">
      <Navbar />

      {/* Hero */}
      <section className="relative pt-32 pb-20 px-6 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#D4AF37]/10 to-transparent" />
        <div className="max-w-6xl mx-auto relative z-10">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37]/30 mb-6">
              <PenTool className="w-4 h-4 text-[#D4AF37]" />
              <span className="text-xs font-medium text-[#D4AF37] tracking-wider uppercase">scribe.senegal-telecom.com</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold mb-4 bg-gradient-to-r from-[#D4AF37] via-[#F5E6D3] to-[#0F8B8D] bg-clip-text text-transparent">SCRIBE</h1>
            <p className="text-2xl md:text-3xl text-white/70 font-light mb-2 italic font-serif">Nand Patrimoine</p>
            <p className="text-lg text-white/50 max-w-2xl mx-auto">Plateforme de transcription et d'annotation audio intelligente pour la préservation des langues et cultures sénégalaises.</p>

            <div className="flex flex-wrap justify-center gap-6 mt-10">
              <div className="flex items-center gap-3 glass px-5 py-3 rounded-xl">
                <Mic className="w-5 h-5 text-[#D4AF37]" />
                <div className="text-left"><div className="text-lg font-bold">{supportedLanguages.length}</div><div className="text-xs text-white/50">Langues supportées</div></div>
              </div>
              <div className="flex items-center gap-3 glass px-5 py-3 rounded-xl">
                <FileText className="w-5 h-5 text-[#00E5A0]" />
                <div className="text-left"><div className="text-lg font-bold">{projects.length}</div><div className="text-xs text-white/50">Projets actifs</div></div>
              </div>
              <div className="flex items-center gap-3 glass px-5 py-3 rounded-xl">
                <Headphones className="w-5 h-5 text-[#0F8B8D]" />
                <div className="text-left"><div className="text-lg font-bold">{formatTime(projects.reduce((s, p) => s + p.duration, 0))}</div><div className="text-xs text-white/50">Audio transcrit</div></div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Tabs */}
      <div className="sticky top-20 z-40 bg-[#050A14]/90 backdrop-blur-md border-b border-white/10">
        <div className="max-w-6xl mx-auto px-6 flex gap-1">
          {[
            { id: 'projects' as const, label: 'Projets', icon: Layers },
            { id: 'transcribe' as const, label: 'Transcrire', icon: Mic },
            { id: 'editor' as const, label: 'Éditeur', icon: PenTool },
            { id: 'corpus' as const, label: 'Corpus', icon: BookOpen }
          ].map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-5 py-3 text-sm font-medium transition-all ${activeTab === tab.id ? 'text-[#D4AF37] border-b-2 border-[#D4AF37]' : 'text-white/50 hover:text-white/80'}`}>
              <tab.icon className="w-4 h-4" /> {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-6 py-12 pb-32">
        {activeTab === 'projects' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold">Projets de transcription</h2>
              <button onClick={() => setActiveTab('transcribe')} className="px-4 py-2 rounded-lg bg-[#D4AF37]/20 text-[#D4AF37] text-sm font-medium hover:bg-[#D4AF37]/30 transition-colors flex items-center gap-2">
                <Upload className="w-4 h-4" /> Nouveau projet
              </button>
            </div>
            <div className="space-y-4">
              {projects.map((project, idx) => {
                const status = statusConfig[project.status];
                return (
                  <motion.div key={project.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.1 }}
                    onClick={() => { setActiveProject(project); setActiveTab('editor'); }}
                    className="glass-card p-6 rounded-xl cursor-pointer hover:border-[#D4AF37]/40 transition-all group">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center">
                          <FileText className="w-5 h-5 text-[#D4AF37]" />
                        </div>
                        <div>
                          <h3 className="font-bold text-lg group-hover:text-[#D4AF37] transition-colors">{project.name}</h3>
                          <div className="flex items-center gap-3 text-sm text-white/50 mt-1">
                            <span>{project.language}</span>
                            <span className="w-1 h-1 rounded-full bg-white/20" />
                            <span>{formatTime(project.duration)}</span>
                            <span className="w-1 h-1 rounded-full bg-white/20" />
                            <span>{project.segments.length} segments</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 text-xs" style={{ color: status.color }}>
                          <status.icon className="w-3 h-3" /> {status.label}
                        </div>
                        <ChevronRight className="w-5 h-5 text-white/20 group-hover:text-[#D4AF37] transition-colors" />
                      </div>
                    </div>
                    {project.segments.length > 0 && (
                      <div className="mt-4 pt-4 border-t border-white/5">
                        <p className="text-sm text-white/40 line-clamp-2">{project.segments[0].text}</p>
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        )}

        {activeTab === 'transcribe' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <h2 className="text-2xl font-bold mb-6">Nouvelle transcription</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Upload / Record */}
              <div className="glass-card p-8 rounded-2xl">
                <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
                  <Upload className="w-5 h-5 text-[#D4AF37]" /> Importer ou enregistrer
                </h3>
                <div className="space-y-6">
                  <div>
                    <label className="text-sm text-white/50 mb-2 block">Nom du projet</label>
                    <input type="text" value={newProjectName} onChange={e => setNewProjectName(e.target.value)} placeholder="Ex: Conte traditionnel - Nom du village" className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-[#D4AF37] outline-none" />
                  </div>
                  <div>
                    <label className="text-sm text-white/50 mb-2 block">Langue du contenu</label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                      {supportedLanguages.map(lang => (
                        <button key={lang.code} onClick={() => setSelectedLang(lang.code)}
                          className={`p-3 rounded-xl border text-left transition-all ${selectedLang === lang.code ? 'border-[#D4AF37] bg-[#D4AF37]/20' : 'border-white/10 bg-white/5 hover:bg-white/10'}`}>
                          <div className="text-lg mb-1">{lang.flag}</div>
                          <div className="text-sm font-medium">{lang.name}</div>
                          <div className="text-xs text-white/40">{lang.model}</div>
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="border-t border-white/10 pt-6">
                    <div className="flex items-center gap-4">
                      <button onClick={() => setIsRecording(!isRecording)}
                        className={`w-16 h-16 rounded-full flex items-center justify-center transition-all ${isRecording ? 'bg-red-500/20 animate-pulse' : 'bg-[#D4AF37]/20 hover:bg-[#D4AF37]/30'}`}>
                        <Mic className={`w-6 h-6 ${isRecording ? 'text-red-400' : 'text-[#D4AF37]'}`} />
                      </button>
                      <div>
                        <p className="font-medium">{isRecording ? 'Enregistrement en cours...' : 'Enregistrer audio'}</p>
                        <p className="text-sm text-white/50">{formatTime(recordTime)}</p>
                      </div>
                      {isRecording && (
                        <button onClick={() => { setIsRecording(false); setRecordTime(0); }} className="ml-auto px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 transition-colors">
                          <RotateCcw className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                  <button onClick={handleCreateProject} disabled={!newProjectName.trim()}
                    className="w-full py-3 rounded-xl bg-[#D4AF37] text-[#050A14] font-bold hover:bg-[#D4AF37]/80 transition-colors disabled:opacity-40">
                    Créer le projet
                  </button>
                </div>
              </div>

              {/* Supported formats */}
              <div className="space-y-4">
                <div className="glass-card p-6 rounded-xl">
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <FileText className="w-4 h-4 text-[#00E5A0]" /> Formats supportés
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {['MP3', 'WAV', 'FLAC', 'M4A', 'OGG', 'WEBM'].map(fmt => (
                      <span key={fmt} className="px-3 py-1 rounded-lg bg-white/5 text-xs text-white/60">{fmt}</span>
                    ))}
                  </div>
                </div>
                <div className="glass-card p-6 rounded-xl">
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <Zap className="w-4 h-4 text-[#D4AF37]" /> Technologies
                  </h4>
                  <ul className="space-y-2 text-sm text-white/50">
                    <li className="flex items-center gap-2"><CheckCircle className="w-3 h-3 text-[#00E5A0]" /> OpenAI Whisper fine-tuned Wolof</li>
                    <li className="flex items-center gap-2"><CheckCircle className="w-3 h-3 text-[#00E5A0]" /> Diarization automatique des locuteurs</li>
                    <li className="flex items-center gap-2"><CheckCircle className="w-3 h-3 text-[#00E5A0]" /> Reconnaissance multilingue Wolof-Français</li>
                    <li className="flex items-center gap-2"><CheckCircle className="w-3 h-3 text-[#00E5A0]" /> Export SRT, VTT, JSON, TXT</li>
                  </ul>
                </div>
                <div className="glass-card p-6 rounded-xl">
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <Lock className="w-4 h-4 text-[#0F8B8D]" /> Confidentialité
                  </h4>
                  <p className="text-sm text-white/50">Tous les fichiers audio sont traités sur des serveurs sénégalais. Les données ne quittent jamais le territoire. Chiffrement AES-256.</p>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'editor' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            {!activeProject ? (
              <div className="text-center py-20">
                <PenTool className="w-12 h-12 text-white/20 mx-auto mb-4" />
                <p className="text-white/50 mb-4">Sélectionnez un projet pour commencer l'édition</p>
                <button onClick={() => setActiveTab('projects')} className="px-6 py-3 rounded-xl bg-[#D4AF37]/20 text-[#D4AF37] hover:bg-[#D4AF37]/30 transition-colors">
                  Voir les projets
                </button>
              </div>
            ) : (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-2xl font-bold">{activeProject.name}</h2>
                    <div className="flex items-center gap-3 text-sm text-white/50 mt-1">
                      <span>{activeProject.language}</span>
                      <span>{formatTime(activeProject.duration)}</span>
                      <span className="px-2 py-0.5 rounded text-xs" style={{ color: statusConfig[activeProject.status].color, background: `${statusConfig[activeProject.status].color}20` }}>
                        {statusConfig[activeProject.status].label}
                      </span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button className="px-3 py-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors flex items-center gap-2 text-sm">
                      <Download className="w-4 h-4" /> Export
                    </button>
                    <button className="px-3 py-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors flex items-center gap-2 text-sm">
                      <Share2 className="w-4 h-4" /> Partager
                    </button>
                  </div>
                </div>

                {/* Player */}
                <div className="glass-card p-6 rounded-xl mb-6">
                  <div className="flex items-center gap-4">
                    <button onClick={() => setIsPlaying(!isPlaying)} className="w-12 h-12 rounded-full bg-[#D4AF37]/20 flex items-center justify-center hover:bg-[#D4AF37]/30 transition-colors">
                      {isPlaying ? <Pause className="w-5 h-5 text-[#D4AF37]" /> : <Play className="w-5 h-5 text-[#D4AF37] ml-0.5" />}
                    </button>
                    <div className="flex-1">
                      <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden cursor-pointer">
                        <div className="h-full bg-gradient-to-r from-[#D4AF37] to-[#0F8B8D] rounded-full" style={{ width: `${(currentTime / (activeProject.duration || 1)) * 100}%` }} />
                      </div>
                      <div className="flex justify-between text-xs text-white/40 mt-1">
                        <span>{formatTime(currentTime)}</span>
                        <span>{formatTime(activeProject.duration)}</span>
                      </div>
                    </div>
                    <Volume2 className="w-5 h-5 text-white/40" />
                  </div>
                </div>

                {/* Segments */}
                <div className="space-y-3">
                  {activeProject.segments.length === 0 ? (
                    <div className="glass-card p-12 rounded-xl text-center">
                      <Radio className="w-10 h-10 text-white/20 mx-auto mb-3" />
                      <p className="text-white/40">Aucun segment transcrit encore</p>
                      <button onClick={() => setActiveTab('transcribe')} className="mt-4 px-4 py-2 rounded-lg bg-[#D4AF37]/20 text-[#D4AF37] text-sm">
                        Lancer la transcription
                      </button>
                    </div>
                  ) : (
                    activeProject.segments.map((seg) => (
                      <div key={seg.id} className="glass-card p-4 rounded-xl hover:border-white/20 transition-colors">
                        <div className="flex items-start gap-4">
                          <div className="flex flex-col items-center gap-1 pt-1">
                            <span className="text-xs font-mono text-white/40">{formatTime(seg.start)}</span>
                            <div className="w-px h-8 bg-white/10" />
                            <span className="text-xs font-mono text-white/40">{formatTime(seg.end)}</span>
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              {seg.speaker && <span className="text-xs px-2 py-0.5 rounded bg-[#4D6BFF]/20 text-[#4D6BFF]">{seg.speaker}</span>}
                              <span className={`text-xs ${confidenceColor(seg.confidence)}`}>{Math.round(seg.confidence * 100)}% confiance</span>
                              <span className="text-xs text-white/30">{seg.lang}</span>
                            </div>
                            {editingSegment === seg.id ? (
                              <div className="flex items-start gap-2">
                                <textarea value={editText} onChange={e => setEditText(e.target.value)} className="flex-1 px-3 py-2 rounded-lg bg-white/5 border border-[#D4AF37]/30 outline-none text-sm min-h-[60px]" />
                                <button onClick={() => handleSaveSegment(seg.id)} className="px-3 py-2 rounded-lg bg-[#00E5A0]/20 text-[#00E5A0]">
                                  <Save className="w-4 h-4" />
                                </button>
                              </div>
                            ) : (
                              <p className="text-white/80 leading-relaxed">{seg.text}</p>
                            )}
                          </div>
                          <div className="flex gap-1">
                            <button onClick={() => { setEditingSegment(seg.id); setEditText(seg.text); }} className="p-2 rounded-lg hover:bg-white/10 transition-colors">
                              <Type className="w-4 h-4 text-white/40" />
                            </button>
                            <button className="p-2 rounded-lg hover:bg-white/10 transition-colors">
                              <Play className="w-4 h-4 text-white/40" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </motion.div>
        )}

        {activeTab === 'corpus' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <h2 className="text-2xl font-bold mb-6">Corpus linguistique NAND</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="glass-card p-6 rounded-xl">
                <div className="flex items-center gap-3 mb-4">
                  <Globe className="w-8 h-8 text-[#D4AF37]" />
                  <div>
                    <h3 className="font-bold">12,450+ heures</h3>
                    <p className="text-sm text-white/50">Audio transcrit et annoté</p>
                  </div>
                </div>
                <div className="space-y-2">
                  {[{ lang: 'Wolof', pct: 45, color: '#0F8B8D' }, { lang: 'Peul', pct: 15, color: '#4D6BFF' }, { lang: 'Sérère', pct: 12, color: '#00E5A0' }, { lang: 'Diola', pct: 8, color: '#D4AF37' }, { lang: 'Mandinka', pct: 6, color: '#F5E6D3' }, { lang: 'Autres', pct: 14, color: '#8B95A8' }].map(l => (
                    <div key={l.lang} className="flex items-center gap-3">
                      <span className="text-xs w-16">{l.lang}</span>
                      <div className="flex-1 h-2 bg-white/10 rounded-full overflow-hidden">
                        <div className="h-full rounded-full" style={{ width: `${l.pct}%`, backgroundColor: l.color }} />
                      </div>
                      <span className="text-xs text-white/40 w-8">{l.pct}%</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="glass-card p-6 rounded-xl">
                <h3 className="font-bold mb-4">Types de contenu</h3>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { icon: BookOpen, label: 'Contes', count: '2,340' },
                    { icon: Mic, label: 'Interviews', count: '1,890' },
                    { icon: Music, label: 'Musique', count: '890' },
                    { icon: Radio, label: 'Radio', count: '3,450' },
                    { icon: PenTool, label: 'Poésie', count: '670' },
                    { icon: Volume2, label: 'Conversations', count: '3,210' }
                  ].map(item => (
                    <div key={item.label} className="flex items-center gap-3 p-3 rounded-lg bg-white/5">
                      <item.icon className="w-4 h-4 text-[#D4AF37]" />
                      <div>
                        <p className="text-sm font-medium">{item.label}</p>
                        <p className="text-xs text-white/40">{item.count} enregistrements</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="glass-card p-8 rounded-xl">
              <h3 className="font-bold mb-4 flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-[#D4AF37]" /> Mission NAND Patrimoine
              </h3>
              <p className="text-white/60 leading-relaxed">
                SENEGAL TELECOM s'engage dans la préservation numérique des langues nationales sénégalaises.
                Notre corpus linguistique est le plus grand d'Afrique de l'Ouest avec plus de 12,450 heures
                de contenu audio transcrit et annoté. Chaque contribution enrichit l'héritage culturel
                pour les générations futures. Les données sont mises à disposition des chercheurs,
                linguistes et développeurs de modèles d'IA sous licence Creative Commons.
              </p>
              <div className="flex gap-4 mt-6">
                <button className="px-5 py-2.5 rounded-lg bg-[#D4AF37]/20 text-[#D4AF37] text-sm font-medium hover:bg-[#D4AF37]/30 transition-colors">
                  Accéder au dataset
                </button>
                <button className="px-5 py-2.5 rounded-lg bg-white/5 text-white/60 text-sm hover:bg-white/10 transition-colors">
                  API Documentation
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </div>

      <footer className="border-t border-white/10 py-12 px-6">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-sm text-white/30">SCRIBE NAND Patrimoine — Préservation linguistique par SENEGAL TELECOM</p>
          <p className="text-xs text-white/20 mt-2">Tous les droits culturels sont préservés pour les communautés d'origine</p>
        </div>
      </footer>
    </div>
  );
}
