import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Navbar from '../components/Navbar';
import { ShoppingCart, Star, Headphones, Shield, Check, X, Plus, Minus, Truck, RotateCcw } from 'lucide-react';

const categories = ['Tous', 'Forfaits', 'Telephones', 'Accessoires', 'Box Internet'];

const products = [
  { id: 1, name: 'Forfait Illimite 5G', price: 15000, oldPrice: 20000, category: 'Forfaits', image: '/p1-5g.jpg', badge: 'POPULAIRE', rating: 4.9, reviews: 2340, features: ['Data illimite', 'Appels illimites', '5G+'], desc: 'Le forfait ultime pour les utilisateurs exigeants. Data illimitee, appels illimites vers tous les reseaux nationaux et 500 min internationales.' },
  { id: 2, name: 'iPhone 16 Pro Max', price: 850000, oldPrice: 950000, category: 'Telephones', image: '/p2-phones.jpg', badge: 'NOUVEAU', rating: 5.0, reviews: 890, features: ['256GB', '5G', 'A18 Pro'], desc: 'Le smartphone Apple le plus avance. Ecran Super Retina XDR 6.9", puce A18 Pro, systeme photo 48MP.' },
  { id: 3, name: 'Box Fibre 1Gbps', price: 25000, oldPrice: 35000, category: 'Box Internet', image: '/p1-fiber.jpg', badge: '-29%', rating: 4.8, reviews: 4120, features: ['1 Gbps', 'WiFi 6E', 'TV 200 chaines'], desc: 'La connexion fibre la plus rapide du Senegal. Jusqu\'a 1 Gbps en download, WiFi 6E, decodeur TV avec 200 chaines incluses.' },
  { id: 4, name: 'Forfait Etudiant', price: 5000, oldPrice: 7500, category: 'Forfaits', image: '/p1-family.jpg', badge: 'PROMO', rating: 4.7, reviews: 5670, features: ['50Go', 'Reseaux sociaux ill.', 'SMS illimites'], desc: 'Specialement concu pour les etudiants. 50Go de data, reseaux sociaux illimites, SMS illimites et appels vers 2 numéros favoris.' },
  { id: 5, name: 'Samsung Galaxy S25 Ultra', price: 720000, oldPrice: 820000, category: 'Telephones', image: '/img-store-hero.jpg', badge: 'PROMO', rating: 4.8, reviews: 1230, features: ['512GB', '5G', 'AI Galaxy'], desc: 'Le flagship Samsung avec S Pen integre. Ecran AMOLED 6.9", IA Galaxy integrée, appareil photo 200MP.' },
  { id: 6, name: 'Ecouteurs ST Pro Max', price: 45000, oldPrice: 55000, category: 'Accessoires', image: '/p1-hero.jpg', badge: null, rating: 4.6, reviews: 890, features: ['ANC', '40h autonomie', 'BT 5.3'], desc: 'Ecouteurs sans fil premium avec reduction active de bruit. Autonomie de 40h avec le boitier, son spatial Dolby Atmos.' },
  { id: 7, name: 'Box Fibre 100Mbps', price: 15000, oldPrice: 20000, category: 'Box Internet', image: '/p1-cybercafe.jpg', badge: 'BEST', rating: 4.9, reviews: 8900, features: ['100 Mbps', 'WiFi 6', 'TV 150 chaines'], desc: 'Notre box la plus populaire. 100 Mbps symetrique, WiFi 6, decodeur TV avec 150 chaines et replay inclus.' },
  { id: 8, name: 'Forfait Data 100Go', price: 10000, oldPrice: 12500, category: 'Forfaits', image: '/p4-neural.jpg', badge: null, rating: 4.5, reviews: 3450, features: ['100Go', 'Validite 30j', 'Rollover'], desc: '100Go de data mobile valables 30 jours. Rollover du data non utilise. Parfait pour le teletravail et le streaming.' },
  { id: 9, name: 'Xiaomi 15 Pro', price: 385000, oldPrice: 420000, category: 'Telephones', image: '/img-srv-1.jpg', badge: null, rating: 4.7, reviews: 2100, features: ['256GB', '5G', 'Leica Optics'], desc: 'Le partenariat Xiaomi x Leica offre une qualite photo exceptionnelle. Charge 120W, ecran LTPO 120Hz.' },
];

export default function Store() {
  const [activeCategory, setActiveCategory] = useState('Tous');
  const [cart, setCart] = useState<{ product: typeof products[0]; qty: number }[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<typeof products[0] | null>(null);

  const filtered = activeCategory === 'Tous' ? products : products.filter(p => p.category === activeCategory);
  const cartTotal = cart.reduce((sum, item) => sum + item.product.price * item.qty, 0);
  const cartCount = cart.reduce((sum, item) => sum + item.qty, 0);

  const addToCart = (product: typeof products[0]) => {
    setCart(prev => { const existing = prev.find(i => i.product.id === product.id); if (existing) return prev.map(i => i.product.id === product.id ? { ...i, qty: i.qty + 1 } : i); return [...prev, { product, qty: 1 }]; });
  };

  const updateQty = (id: number, delta: number) => {
    setCart(prev => prev.map(i => i.product.id === id ? { ...i, qty: Math.max(1, i.qty + delta) } : i));
  };

  const removeFromCart = (id: number) => setCart(prev => prev.filter(i => i.product.id !== id));

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-[#E0E6F1]">
      <Navbar />
      {/* HERO */}
      <section className="relative pt-32 pb-16 overflow-hidden">
        <div className="absolute inset-0"><img src="/p2-phones.jpg" alt="" className="w-full h-full object-cover opacity-30" /><div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0f] via-[#0a0a0f]/80 to-[#0a0a0f]" /></div>
        <div className="relative z-10 max-w-[1440px] mx-auto px-6 lg:px-12">
          <motion.div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-8" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#FF6B35]/30 glass"><ShoppingCart className="w-4 h-4 text-[#FF6B35]" /><span className="text-sm font-medium text-[#FF6B35] tracking-wider">Boutique Officielle</span></div>
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">STORE <span className="text-gradient-fire">SENEGAL TELECOM</span></h1>
              <p className="text-lg text-[#8B95A8] max-w-lg">Forfaits mobiles, telephones dernier cri, box internet et accessoires premium. Livraison gratuite partout au Senegal.</p>
            </div>
            <button onClick={() => setCartOpen(true)} className="flex items-center gap-3 px-6 py-3 rounded-xl glass hover:border-[#FF6B35]/30 transition-all group">
              <div className="relative"><ShoppingCart className="w-6 h-6 text-[#FF6B35]" />{cartCount > 0 && <span className="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-[#FF6B35] text-white text-xs flex items-center justify-center">{cartCount}</span>}</div>
              <span className="text-sm text-[#8B95A8] group-hover:text-[#E0E6F1] transition-colors">{cartCount} article{cartCount > 1 ? 's' : ''} — {cartTotal.toLocaleString()} FCFA</span>
            </button>
          </motion.div>
        </div>
      </section>

      {/* PRODUCTS */}
      <section className="py-12 pb-24">
        <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
          <div className="flex flex-wrap gap-3 mb-12">
            {categories.map(cat => (
              <button key={cat} onClick={() => setActiveCategory(cat)} className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all ${activeCategory === cat ? 'bg-[#FF6B35] text-white shadow-lg shadow-[#FF6B35]/20' : 'glass text-[#8B95A8] hover:text-[#E0E6F1]'}`}>{cat}</button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            <motion.div key={activeCategory} className="grid md:grid-cols-2 lg:grid-cols-3 gap-6" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} transition={{ duration: 0.3 }}>
              {filtered.map((product, i) => (
                <motion.div key={product.id} className="group relative rounded-2xl overflow-hidden glass hover:border-[#FF6B35]/20 transition-all duration-500 cursor-pointer" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: i * 0.08 }} onClick={() => setSelectedProduct(product)}>
                  {product.badge && <div className="absolute top-4 left-4 z-10 px-3 py-1 rounded-full text-xs font-bold bg-[#FF6B35] text-white animate-pulse-glow">{product.badge}</div>}
                  <div className="relative h-52 overflow-hidden"><img src={product.image} alt={product.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" /><div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0f] to-transparent" /></div>
                  <div className="p-5 space-y-3">
                    <div className="flex items-center justify-between"><div className="flex items-center gap-1"><Star className="w-4 h-4 text-[#FFD23F] fill-[#FFD23F]" /><span className="text-sm text-[#8B95A8]">{product.rating}</span><span className="text-xs text-[#8B95A8]">({product.reviews})</span></div><span className="text-xs text-[#8B95A8] px-2 py-0.5 rounded-full glass">{product.category}</span></div>
                    <h3 className="text-lg font-bold text-[#E0E6F1] font-['Space_Grotesk']">{product.name}</h3>
                    <div className="flex flex-wrap gap-1.5">{product.features.map(f => <span key={f} className="px-2 py-0.5 text-[10px] rounded border border-white/10 text-[#8B95A8]">{f}</span>)}</div>
                    <div className="flex items-center gap-3 pt-1"><span className="text-2xl font-bold text-[#FF6B35]">{product.price.toLocaleString()} FCFA</span>{product.oldPrice && <span className="text-sm text-[#8B95A8] line-through">{product.oldPrice.toLocaleString()} FCFA</span>}</div>
                    <button onClick={(e) => { e.stopPropagation(); addToCart(product); }} className="w-full py-3 rounded-xl bg-[#FF6B35] text-white font-semibold hover:bg-[#e55a2b] transition-all flex items-center justify-center gap-2 active:scale-95">Ajouter au panier <ShoppingCart className="w-4 h-4" /></button>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </AnimatePresence>
        </div>
      </section>

      {/* FEATURES BAR */}
      <section className="py-16 border-t border-white/5">
        <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {[{ icon: Truck, title: 'Livraison rapide', desc: '24-48h partout au Senegal' }, { icon: Shield, title: 'Garantie 2 ans', desc: 'Sur tous nos produits' }, { icon: Headphones, title: 'Support 24/7', desc: 'Assistance permanente' }, { icon: RotateCcw, title: 'Satisfait ou rembourse', desc: '30 jours pour retourner' }].map(f => (
              <div key={f.title} className="text-center space-y-2"><f.icon className="w-8 h-8 text-[#FF6B35] mx-auto" /><h4 className="text-sm font-semibold text-[#E0E6F1]">{f.title}</h4><p className="text-xs text-[#8B95A8]">{f.desc}</p></div>
            ))}
          </div>
        </div>
      </section>

      {/* CART SIDEBAR */}
      <AnimatePresence>{cartOpen && (
        <motion.div className="fixed inset-0 z-[100]" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setCartOpen(false)} />
          <motion.div className="absolute right-0 top-0 h-full w-full max-w-md bg-[#0f0f18] border-l border-white/10 overflow-y-auto" initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }} transition={{ type: 'spring', damping: 25, stiffness: 200 }}>
            <div className="p-6 border-b border-white/10 flex items-center justify-between"><h3 className="text-xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">Votre Panier</h3><button onClick={() => setCartOpen(false)} className="p-2 rounded-lg hover:bg-white/5 transition-colors"><X className="w-5 h-5" /></button></div>
            <div className="p-6 space-y-4">
              {cart.length === 0 ? <div className="text-center py-12 text-[#8B95A8]">Votre panier est vide</div> : cart.map(item => (
                <div key={item.product.id} className="flex gap-4 p-4 rounded-xl glass">
                  <img src={item.product.image} alt="" className="w-16 h-16 rounded-lg object-cover" />
                  <div className="flex-1"><div className="text-sm font-semibold text-[#E0E6F1]">{item.product.name}</div><div className="text-sm text-[#FF6B35] font-bold">{item.product.price.toLocaleString()} FCFA</div>
                    <div className="flex items-center gap-2 mt-2"><button onClick={() => updateQty(item.product.id, -1)} className="w-6 h-6 rounded-full glass flex items-center justify-center"><Minus className="w-3 h-3" /></button><span className="text-sm">{item.qty}</span><button onClick={() => updateQty(item.product.id, 1)} className="w-6 h-6 rounded-full glass flex items-center justify-center"><Plus className="w-3 h-3" /></button></div>
                  </div>
                  <button onClick={() => removeFromCart(item.product.id)} className="self-start p-1"><X className="w-4 h-4 text-[#8B95A8]" /></button>
                </div>
              ))}
            </div>
            {cart.length > 0 && <div className="p-6 border-t border-white/10 space-y-4">
              <div className="flex justify-between text-lg font-bold"><span>Total</span><span className="text-[#FF6B35]">{cartTotal.toLocaleString()} FCFA</span></div>
              <button className="w-full py-4 rounded-xl bg-[#FF6B35] text-white font-bold hover:bg-[#e55a2b] transition-colors">Commander</button>
            </div>}
          </motion.div>
        </motion.div>
      )}</AnimatePresence>

      {/* PRODUCT DETAIL MODAL */}
      <AnimatePresence>{selectedProduct && (
        <motion.div className="fixed inset-0 z-[100] flex items-center justify-center p-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setSelectedProduct(null)} />
          <motion.div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl bg-[#0f0f18] border border-white/10" initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}>
            <button onClick={() => setSelectedProduct(null)} className="absolute top-4 right-4 z-10 p-2 rounded-full glass"><X className="w-5 h-5" /></button>
            <img src={selectedProduct.image} alt="" className="w-full h-64 object-cover" />
            <div className="p-6 space-y-4">
              <div className="flex items-center gap-2"><div className="flex gap-0.5">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className={`w-4 h-4 ${i < Math.floor(selectedProduct.rating) ? 'text-[#FFD23F] fill-[#FFD23F]' : 'text-[#8B95A8]'}`} />)}</div><span className="text-sm text-[#8B95A8]">({selectedProduct.reviews} avis)</span></div>
              <h2 className="text-2xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">{selectedProduct.name}</h2>
              <p className="text-sm text-[#8B95A8] leading-relaxed">{selectedProduct.desc}</p>
              <div className="flex flex-wrap gap-2">{selectedProduct.features.map(f => <span key={f} className="px-3 py-1 text-xs rounded-full glass flex items-center gap-1"><Check className="w-3 h-3 text-[#00E5A0]" />{f}</span>)}</div>
              <div className="flex items-center gap-4 pt-2"><span className="text-3xl font-bold text-[#FF6B35]">{selectedProduct.price.toLocaleString()} FCFA</span>{selectedProduct.oldPrice && <span className="text-lg text-[#8B95A8] line-through">{selectedProduct.oldPrice.toLocaleString()} FCFA</span>}</div>
              <button onClick={() => { addToCart(selectedProduct); setSelectedProduct(null); }} className="w-full py-4 rounded-xl bg-[#FF6B35] text-white font-bold hover:bg-[#e55a2b] transition-colors flex items-center justify-center gap-2">Ajouter au panier <ShoppingCart className="w-5 h-5" /></button>
            </div>
          </motion.div>
        </motion.div>
      )}</AnimatePresence>
    </div>
  );
}
