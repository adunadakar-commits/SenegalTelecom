import { useState } from 'react';
import { motion } from 'framer-motion';
import Navbar from '../components/Navbar';
import { Sparkles, BookOpen, Compass, Clock, Sun, Shield } from 'lucide-react';

const miracles = [
  { title: 'Prière des Miracles', desc: 'Cette prière est une invocation spéciale qui a le pouvoir d\'attirer les faveurs divines.', icon: Sparkles, color: '#D4AF37' },
  { title: 'Protection Divine', desc: 'Invocations pour se protéger du mal et des énergies négatives.', icon: Shield, color: '#4D6BFF' },
  { title: 'Coran Digital', desc: 'Accès au Coran avec récitation audio, traduction et tafsir.', icon: BookOpen, color: '#1B8A4C' },
  { title: 'Qibla Miracle', desc: 'Localisation précise de la Qibla avec réalité augmentée.', icon: Compass, color: '#00E5FF' },
  { title: 'Horaires Saints', desc: 'Horaires de prière exacts pour chaque ville avec notifications.', icon: Clock, color: '#FF6B35' },
  { title: 'Lumière Spirituelle', desc: 'Méditations guidées et rappels spirituels quotidiens.', icon: Sun, color: '#FFD23F' },
];

const duas = [
  { arabic: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', transliteration: 'Bismillahi r-Rahmani r-Rahim', french: 'Au nom d\'Allah, le Tout Miséricordieux, le Très Miséricordieux.', source: 'Al-Fatiha 1:1' },
  { arabic: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ', transliteration: 'Alhamdu lillahi Rabbil 3alamin', french: 'Louange à Allah, Seigneur de tous les mondes.', source: 'Al-Fatiha 1:2' },
  { arabic: 'اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا', transliteration: 'Allahumma inni as-aluka 3ilman nafi3an', french: 'Ô Allah, je Te demande une science profitable.', source: 'Hadith authentique' },
  { arabic: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ', transliteration: 'La hawla wa la quwwata illa billah', french: 'Il n\'y a de force ni de puissance qu\'en Allah.', source: 'Hadith Bukhari' },
  { arabic: 'رَبِّ زِدْنِي عِلْمًا', transliteration: 'Rabbi zidni 3ilma', french: 'Mon Seigneur, accorde-moi davantage de science.', source: 'Ta-Ha 20:114' },
];

export default function Miracle() {
  const [activeDua, setActiveDua] = useState(0);

  return (
    <div className="min-h-screen bg-[#0a0a1f] text-[#E0E6F1]">
      <Navbar />
      
      {/* HERO */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a1f] via-[#1a1040] to-[#0a1f14]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(212,175,55,0.15),transparent_50%),radial-gradient(circle_at_70%_20%,rgba(77,107,255,0.1),transparent_50%)]" />
          {/* Stars */}
          {Array.from({ length: 50 }).map((_, i) => (
            <div key={i} className="absolute rounded-full bg-white animate-pulse" style={{ top: `${Math.random()*100}%`, left: `${Math.random()*100}%`, width: `${Math.random()*2+1}px`, height: `${Math.random()*2+1}px`, animationDelay: `${Math.random()*3}s`, opacity: 0.3 + Math.random()*0.5 }} />
          ))}
        </div>
        
        <div className="relative z-10 max-w-[1440px] mx-auto px-6 lg:px-12 text-center">
          <motion.div className="space-y-6" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-[#D4AF37]/30 glass">
              <Sparkles className="w-4 h-4 text-[#D4AF37]" />
              <span className="text-sm font-medium text-[#D4AF37] tracking-wider">miracle.senegal-telecom.com</span>
            </div>
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold font-['Space_Grotesk']">
              SENEGAL TELECOM <span className="text-gradient-gold">MIRACLE</span>
            </h1>
            <p className="text-xl text-[#8B95A8] max-w-2xl mx-auto">
              La technologie au service de la foi. Rappels spirituels, Coran numérique, Hadith, contenu béni.
            </p>
          </motion.div>
        </div>
      </section>

      {/* DUAS */}
      <section className="py-12">
        <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
          <motion.div className="max-w-3xl mx-auto p-8 rounded-3xl glass-strong border border-[#D4AF37]/20 text-center space-y-6" initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }}>
            <div className="flex items-center justify-center gap-2 mb-2">
              <BookOpen className="w-5 h-5 text-[#D4AF37]" />
              <span className="text-sm text-[#8B95A8] tracking-wider uppercase">Invocations Sacrées</span>
            </div>
            <div className="text-3xl arabic text-[#D4AF37] leading-loose">{duas[activeDua].arabic}</div>
            <div className="text-sm text-[#00E5A0] italic">{duas[activeDua].transliteration}</div>
            <p className="text-lg text-[#E0E6F1]">{duas[activeDua].french}</p>
            <div className="text-xs text-[#8B95A8]">— {duas[activeDua].source}</div>
            <div className="flex justify-center gap-2 mt-4">
              {duas.map((_, i) => (
                <button key={i} onClick={() => setActiveDua(i)} className={`w-3 h-3 rounded-full transition-all ${activeDua === i ? 'bg-[#D4AF37] w-8' : 'bg-[#D4AF37]/30'}`} />
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* SERVICES */}
      <section className="py-16">
        <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
          <motion.div className="text-center mb-12" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <h2 className="text-3xl md:text-4xl font-bold text-[#E0E6F1] font-['Space_Grotesk']">
              Services <span className="text-[#D4AF37]">Spirituels</span>
            </h2>
            <p className="text-[#8B95A8] mt-2">La technologie au service de l'Ummah</p>
          </motion.div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {miracles.map((m, i) => (
              <motion.div key={m.title} className="p-6 rounded-2xl glass hover:border-[#D4AF37]/20 transition-all group" style={{ borderColor: 'rgba(255,255,255,0.05)' }} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}>
                <div className="w-14 h-14 rounded-xl flex items-center justify-center mb-4" style={{ backgroundColor: `${m.color}15` }}>
                  <m.icon className="w-7 h-7" style={{ color: m.color }} />
                </div>
                <h3 className="text-lg font-bold text-[#E0E6F1] font-['Space_Grotesk'] mb-2">{m.title}</h3>
                <p className="text-sm text-[#8B95A8] leading-relaxed">{m.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* BISMILLAH */}
      <section className="py-16 pb-24">
        <div className="max-w-[1440px] mx-auto px-6 lg:px-12 text-center">
          <motion.div className="p-12 rounded-3xl border border-[#D4AF37]/20 glass-strong" initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}>
            <div className="text-5xl md:text-6xl arabic text-[#D4AF37] mb-4 leading-relaxed">بسم الله الرحمن الرحيم</div>
            <p className="text-xl text-[#E0E6F1] italic mb-2">Bismillahi r-Rahmani r-Rahim</p>
            <p className="text-[#8B95A8]">Au nom d'Allah, le Tout Miséricordieux, le Très Miséricordieux</p>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
