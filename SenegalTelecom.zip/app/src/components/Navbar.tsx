import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Signal, ChevronDown, Globe, Sparkles } from 'lucide-react';

const portals = [
  { path: '/', label: 'Principal', color: '#4D6BFF', desc: 'Telecoms' },
  { path: '/store', label: 'Store', color: '#FF6B35', desc: 'Boutique' },
  { path: '/islam', label: 'Islam', color: '#1B8A4C', desc: 'Spiritualite' },
  { path: '/miracle', label: 'Miracle', color: '#D4AF37', desc: 'Spirituel' },
  { path: '/ia', label: 'IA', color: '#7B2D8E', desc: 'Intelligence' },
  { path: '/averoes', label: 'Averroes', color: '#8B4513', desc: 'Education' },
  { path: '/space', label: 'Space', color: '#00E5FF', desc: 'Spatial' },
  { path: '/alphabet', label: 'Alphabet', color: '#1B8A4C', desc: 'Apprentissage' },
  { path: '/nand', label: 'Nand', color: '#0F8B8D', desc: 'Wolof' },
  { path: '/scribe', label: 'Scribe', color: '#D4AF37', desc: 'Patrimoine' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [portalMenuOpen, setPortalMenuOpen] = useState(false);
  const location = useLocation();

  const currentPortal = portals.find(p => p.path === location.pathname) || portals[0];

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => { setMobileOpen(false); setPortalMenuOpen(false); }, [location]);

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${scrolled ? 'glass-strong border-b border-white/8' : 'bg-transparent'}`}>
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group">
            <div className="relative w-10 h-10 flex items-center justify-center">
              <div className="absolute inset-0 rounded-lg rotate-45 opacity-80 transition-all duration-500 group-hover:rotate-90" style={{ backgroundColor: currentPortal.color }} />
              <Signal className="relative z-10 w-5 h-5 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-bold tracking-wider text-[#E0E6F1] font-['Space_Grotesk']">SENEGAL</span>
              <span className="text-xs tracking-[0.3em] font-medium -mt-1" style={{ color: currentPortal.color }}>TELECOM</span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-6">
            {/* Portal Switcher */}
            <div className="relative">
              <button onClick={() => setPortalMenuOpen(!portalMenuOpen)} className="flex items-center gap-2 px-4 py-2.5 rounded-xl glass hover:border-white/15 transition-all text-sm text-[#E0E6F1]">
                <Globe className="w-4 h-4" style={{ color: currentPortal.color }} />
                <span className="font-medium">{currentPortal.label}</span>
                <ChevronDown className={`w-3 h-3 transition-transform ${portalMenuOpen ? 'rotate-180' : ''}`} />
              </button>

              {portalMenuOpen && (
                <div className="absolute top-full mt-2 left-0 w-64 rounded-xl glass-strong shadow-2xl overflow-hidden border border-white/10">
                  <div className="p-3 text-xs text-[#8B95A8] uppercase tracking-wider">Changer de portail</div>
                  {portals.map((portal) => (
                    <Link key={portal.path} to={portal.path} className={`flex items-center gap-3 px-4 py-3 hover:bg-white/5 transition-colors ${location.pathname === portal.path ? 'bg-white/5' : ''}`}>
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: portal.color, boxShadow: `0 0 8px ${portal.color}60` }} />
                      <div className="flex-1"><span className="text-sm text-[#E0E6F1] font-medium">{portal.label}</span><span className="text-xs text-[#8B95A8] ml-2">{portal.desc}</span></div>
                      {location.pathname === portal.path && <Sparkles className="w-3 h-3 text-[#D4AF37]" />}
                    </Link>
                  ))}
                </div>
              )}
            </div>

            <Link to="/store" className="text-sm text-[#8B95A8] hover:text-[#E0E6F1] transition-colors">Boutique</Link>
            <Link to="/miracle" className="text-sm text-[#8B95A8] hover:text-[#E0E6F1] transition-colors">Miracle</Link>
            <Link to="/ia" className="text-sm text-[#8B95A8] hover:text-[#E0E6F1] transition-colors">IA</Link>
            <Link to="/space" className="text-sm text-[#8B95A8] hover:text-[#E0E6F1] transition-colors">Space</Link>

            <Link to="/espace-client" className="px-5 py-2.5 rounded-xl text-sm font-semibold text-white transition-all glow-cyber" style={{ backgroundColor: currentPortal.color }}>Espace Client</Link>
          </div>

          <button className="lg:hidden text-[#E0E6F1] p-2" onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="lg:hidden glass-strong border-t border-white/10">
          <div className="px-6 py-6 space-y-4">
            <div className="text-xs uppercase tracking-wider text-[#8B95A8] mb-2">Portails</div>
            {portals.map(p => (
              <Link key={p.path} to={p.path} className="flex items-center gap-3 py-2.5">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: p.color }} />
                <span className={`text-sm ${location.pathname === p.path ? 'text-[#E0E6F1] font-bold' : 'text-[#8B95A8]'}`}>{p.label}</span>
                <span className="text-xs text-[#8B95A8] ml-auto">{p.desc}</span>
              </Link>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
}
