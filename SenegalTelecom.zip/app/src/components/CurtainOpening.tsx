import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Signal } from 'lucide-react';

export default function CurtainOpening({ onComplete }: { onComplete: () => void }) {
  const [phase, setPhase] = useState<'loading' | 'opening' | 'done'>('loading');

  useEffect(() => {
    // Phase 1: Loading text (0-1.5s)
    const t1 = setTimeout(() => setPhase('opening'), 1500);
    // Phase 2: Open curtains (1.5-3.5s)
    const t2 = setTimeout(() => {
      setPhase('done');
      onComplete();
    }, 3500);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [onComplete]);

  return (
    <AnimatePresence>
      {phase !== 'done' && (
        <motion.div
          className="fixed inset-0 z-[9999] flex items-center justify-center"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8, ease: 'easeInOut' }}
        >
          {/* Dark background */}
          <div className="absolute inset-0 bg-[#050A14]" />

          {/* Left Curtain */}
          <motion.div
            className="absolute top-0 left-0 h-full bg-gradient-to-r from-[#03060e] via-[#0B1426] to-[#0B1426]"
            style={{ width: '50%', boxShadow: 'inset -20px 0 60px rgba(0,0,0,0.9)' }}
            initial={{ x: 0 }}
            animate={phase === 'opening' ? { x: '-100%' } : { x: 0 }}
            transition={{ duration: 1.5, ease: [0.77, 0, 0.175, 1] }}
          >
            <div className="absolute right-0 top-0 h-full w-1 bg-gradient-to-b from-transparent via-[#4D6BFF]/60 to-transparent" />
          </motion.div>

          {/* Right Curtain */}
          <motion.div
            className="absolute top-0 right-0 h-full bg-gradient-to-l from-[#03060e] via-[#0B1426] to-[#0B1426]"
            style={{ width: '50%', boxShadow: 'inset 20px 0 60px rgba(0,0,0,0.9)' }}
            initial={{ x: 0 }}
            animate={phase === 'opening' ? { x: '100%' } : { x: 0 }}
            transition={{ duration: 1.5, ease: [0.77, 0, 0.175, 1] }}
          >
            <div className="absolute left-0 top-0 h-full w-1 bg-gradient-to-b from-transparent via-[#4D6BFF]/60 to-transparent" />
          </motion.div>

          {/* Center Logo */}
          <motion.div
            className="relative z-10 flex flex-col items-center gap-4"
            initial={{ opacity: 1, scale: 1 }}
            animate={phase === 'opening' ? { opacity: 0, scale: 0.8 } : { opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
          >
            <div className="relative w-20 h-20 flex items-center justify-center">
              <motion.div
                className="absolute inset-0 bg-[#4D6BFF] rounded-xl"
                animate={{ rotate: 45 }}
                transition={{ repeat: Infinity, duration: 2, ease: 'easeInOut' }}
                style={{
                  boxShadow: '0 0 30px rgba(77,107,255,0.5), 0 0 60px rgba(77,107,255,0.3)',
                }}
              />
              <Signal className="relative z-10 w-10 h-10 text-white" />
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold tracking-[0.3em] text-[#E0E6F1]">SENEGAL</div>
              <div className="text-lg tracking-[0.5em] text-[#4D6BFF] font-medium">TELECOM</div>
            </div>
            <div className="w-32 h-0.5 bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent mt-2" />
            <div className="text-sm text-[#8B95A8] tracking-widest uppercase mt-1">
              {phase === 'loading' ? 'Chargement...' : "L'Afrique Connectee"}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
