import { useState, useCallback } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import CurtainOpening from './components/CurtainOpening';
import Home from './pages/Home';
import Store from './pages/Store';
import Islam from './pages/Islam';
import IA from './pages/IA';
import Averoes from './pages/Averoes';
import Space from './pages/Space';
import Alphabet from './pages/Alphabet';
import Miracle from './pages/Miracle';
import EspaceClient from './pages/EspaceClient';

import Nand from './pages/Nand';
import Scribe from './pages/Scribe';

const pageVariants = {
  initial: { opacity: 0, y: 20, scale: 0.98 },
  animate: { opacity: 1, y: 0, scale: 1 },
  exit: { opacity: 0, y: -20, scale: 0.98 },
};

function AnimatedPage({ children }: { children: React.ReactNode }) {
  return (
    <motion.div
      variants={pageVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      transition={{ duration: 0.5, ease: [0.19, 1, 0.22, 1] }}
    >
      {children}
    </motion.div>
  );
}

function App() {
  const [curtainDone, setCurtainDone] = useState(false);
  const location = useLocation();

  const handleCurtainComplete = useCallback(() => {
    setCurtainDone(true);
  }, []);

  return (
    <>
      {!curtainDone && <CurtainOpening onComplete={handleCurtainComplete} />}
      <AnimatePresence mode="wait">
        <Routes location={location} key={location.pathname}>
          <Route path="/" element={<AnimatedPage><Home /></AnimatedPage>} />
          <Route path="/store" element={<AnimatedPage><Store /></AnimatedPage>} />
          <Route path="/islam" element={<AnimatedPage><Islam /></AnimatedPage>} />
          <Route path="/ia" element={<AnimatedPage><IA /></AnimatedPage>} />
          <Route path="/averoes" element={<AnimatedPage><Averoes /></AnimatedPage>} />
          <Route path="/space" element={<AnimatedPage><Space /></AnimatedPage>} />
          <Route path="/alphabet" element={<AnimatedPage><Alphabet /></AnimatedPage>} />
          <Route path="/miracle" element={<AnimatedPage><Miracle /></AnimatedPage>} />
          <Route path="/espace-client" element={<AnimatedPage><EspaceClient /></AnimatedPage>} />
          <Route path="/nand" element={<AnimatedPage><Nand /></AnimatedPage>} />
          <Route path="/scribe" element={<AnimatedPage><Scribe /></AnimatedPage>} />
        </Routes>
      </AnimatePresence>
    </>
  );
}

export default App;
