# SENEGAL TELECOM - Guide de Déploiement

## HashRouter (Recommandé - Fonctionne partout)

Avec HashRouter, aucune configuration serveur n'est nécessaire.
L'URL contient `#/` pour le routing interne.

### URLs après déploiement :
- Principal : `https://senegal-telecom.com/app/#/`
- Store : `https://senegal-telecom.com/app/#/store`
- Islam : `https://senegal-telecom.com/app/#/islam`
- Miracle : `https://senegal-telecom.com/app/#/miracle`
- IA : `https://senegal-telecom.com/app/#/ia`
- Averoes : `https://senegal-telecom.com/app/#/averoes`
- Space : `https://senegal-telecom.com/app/#/space`
- Alphabet : `https://senegal-telecom.com/app/#/alphabet`
- Nand : `https://senegal-telecom.com/app/#/nand`
- Scribe : `https://senegal-telecom.com/app/#/scribe`
- Espace Client : `https://senegal-telecom.com/app/#/espace-client`

### Étapes de déploiement :
1. Videz le dossier `app/` sur votre serveur
2. Uploadez TOUS les fichiers du dossier `dist/` dans `app/`
3. Accédez à `https://senegal-telecom.com/app/`

---

## BrowserRouter (URLs propres sans #)

Si vous voulez des URLs sans `#` (ex: `/app/store` au lieu de `/#/store`),
il faut configurer le serveur pour rediriger toutes les routes vers index.html.

### Apache (.htaccess déjà inclus dans le build)
Le fichier `.htaccess` est fourni. Il redirige automatiquement tout vers index.html.

### Nginx
```nginx
location /app/ {
  try_files $uri $uri/ /app/index.html;
}
```

### URLs propres :
- Principal : `https://senegal-telecom.com/app/`
- Store : `https://senegal-telecom.com/app/store`
- Islam : `https://senegal-telecom.com/app/islam`
- etc.

---

## Important
- Ne mélangez pas les anciens et nouveaux fichiers
- Les fichiers dans `assets/` ont des noms avec hash (ex: `index-C04RqYYn.js`)
- Chaque build génère de nouveaux noms — remplacez tout
